import express from "express";
import cors from "cors";
import authRoutes from "./features/auth/routes/auth.routes.js";
import createChatRoutes from "./features/chat/routes/chat.routes.js";
import createProjectRoutes from "./features/project/presentation/routes/project.routes.js";
import createOrganizationRoutes from "./features/organization/presentation/routes/organization.routes.js";
import createOrganizationMemberRoutes from "./features/organization-member/presentation/routes/organization-member.routes.js";
import createAgentRoutes from "./features/agent/presentation/routes/agent.routes.js";
import createProfileRoutes from "./features/profile/presentation/routes/profile.routes.js";
import createAdminRoutes from "./features/admin/presentation/routes/admin.routes.js";
import { createAdminAuthRoutes } from "./features/admin/admin-auth/presentation/routes/admin-auth.routes.js";
import { authenticate } from "./common/middleware/auth.middleware.js";
import createOrganizationInvitationRoutes from "./features/organization-invitations/presentation/routes/organization-invitation.routes.js";
import { requirePlatformRole } from "./features/admin/presentation/middleware/require-platform-role.middleware.js";
import { PlatformRole } from "./features/admin/domain/constants/platform-role.js";
import { createContextTestRoutes } from "./features/shared/context/presentation/routes/context-test.routes.js";
import { createCompanyProfileRoutes } from "./features/workspace/company/presentation/routes/company-profile.routes.js";
import { createWorkspaceSettingsRoutes } from "./features/workspace/settings/presentation/routes/workspace-settings.routes.js";
import { createWorkspaceMemberRoutes } from "./features/workspace/members/presentation/routes/workspace-member.routes.js";
import createPublicChatRoutes from "./features/public-chat/routes/public-chat.routes.js";
import { createWorkspaceDashboardRoutes } from "./features/workspace/dashboard/presentation/routes/workspace-dashboard.routes.js";
import { createWorkspaceModelRoutes } from "./features/workspace/models/presentation/routes/workspace-model.routes.js";
import { createAISettingsRoutes } from "./features/organization/ai-settings/presentation/routes/ai-settings.routes.js";
import { createAIModelRoutes } from "./features/platform/ai-models/presentation/routes/ai-model.routes.js";
import { createOrganizationModelAccessRoutes } from "./features/platform/organization-model-access/presentation/routes/organization-model-access.routes.js";
import createKnowledgeSourceRoutes from "./features/knowledge/presentation/routes/knowledge-source.routes.js";
import createAgentToolRoutes from "./features/agent-tool/presentation/routes/agent-tool.routes.js";
import createProjectMemberRoutes from "./features/project-member/presentation/routes/project-member.routes.js";
import { createWorkspaceApiKeyRoutes } from "./features/workspace/api-keys/presentation/routes/workspace-api-key.routes.js";
import { createPlatformApiKeyRoutes } from "./features/platform/api-keys/presentation/routes/platform-api-key.routes.js";
import { createPlatformConfigRoutes } from "./features/platform/config/presentation/routes/platform-config.routes.js";

import {
  userRepository,
  jwtService,
  organizationModule,
  organizationMemberModule,
  organizationInvitationModule,
  projectMemberModule,
  projectModule,
  agentModule,
  agentToolModule,
  profileModule,
  adminModule,
  adminAuthModule,
  rbacRepository,
  aiModelModule,
  organizationModelAccessModule,
  aiSettingsModule,
  contextModule,
  companyProfileModule,
  workspaceSettingsModule,
  workspaceApiKeysModule,
  workspaceMemberModule,
  platformApiKeysModule,
  platformConfigModule,
  workspaceDashboardModule,
  workspaceModelModule,
  publicChatModule,
  knowledgeModule,
} from "./container/services.js";
import { errorMiddleware } from "./common/middleware/error.middleware.js";

const app = express();
const authMiddleware = authenticate(userRepository, jwtService);
app.use(
  cors({
    origin: true,
    credentials: true,
    exposedHeaders: ["x-visitor-id"],
  }),
);

app.use(express.json());

app.get("/api/test/company-services", (req, res) => {
  res.json({
    success: true,
    data: {
      services: [
        "Mobile App Development",
        "Website Development",
        "UI/UX Design",
        "AI Solutions",
        "Cloud Services",
        "Digital Marketing",
      ],
    },
  });
});

app.use(
  "/api/v1/platform/ai-models",
  createAIModelRoutes({
    aiModelController: aiModelModule.aiModelController,
    middleware: [
      authMiddleware,
      requirePlatformRole(adminModule.requirePlatformRoleUseCase, [
        PlatformRole.PLATFORM_ADMIN,
        PlatformRole.PLATFORM_MANAGER,
      ]),
    ],
  }),
);

app.use(
  "/api/v1/platform/organization-model-access",
  createOrganizationModelAccessRoutes({
    organizationModelAccessController:
      organizationModelAccessModule.organizationModelAccessController,
    middleware: [
      authMiddleware,
      requirePlatformRole(adminModule.requirePlatformRoleUseCase, [
        PlatformRole.PLATFORM_ADMIN,
        PlatformRole.PLATFORM_MANAGER,
      ]),
    ],
  }),
);

app.use(
  "/api/v1/platform/api-keys",
  createPlatformApiKeyRoutes({
    platformApiKeyController: platformApiKeysModule.platformApiKeyController,
    middleware: [
      authMiddleware,
      requirePlatformRole(adminModule.requirePlatformRoleUseCase, [
        PlatformRole.PLATFORM_ADMIN,
        PlatformRole.PLATFORM_MANAGER,
      ]),
    ],
  }),
);

app.use(
  "/api/v1/platform/config",
  createPlatformConfigRoutes({
    platformConfigController: platformConfigModule.platformConfigController,
    middleware: [
      authMiddleware,
      requirePlatformRole(adminModule.requirePlatformRoleUseCase, [
        PlatformRole.PLATFORM_ADMIN,
        PlatformRole.PLATFORM_MANAGER,
      ]),
    ],
  }),
);

app.use(
  "/api/v1/context-test",
  createContextTestRoutes({
    middlewares: contextModule.middlewares,
  }),
);

app.use(
  "/api/v1/workspace/company",
  createCompanyProfileRoutes({
    companyProfileController: companyProfileModule.companyProfileController,
    middleware: companyProfileModule.contextMiddleware,
  }),
);

app.use(
  "/api/v1/workspace/settings",
  createWorkspaceSettingsRoutes({
    workspaceSettingsController:
      workspaceSettingsModule.workspaceSettingsController,
    middleware: workspaceSettingsModule.contextMiddleware,
  }),
);

app.use(
  "/api/v1/workspace/api-keys",
  createWorkspaceApiKeyRoutes({
    workspaceApiKeyController: workspaceApiKeysModule.workspaceApiKeyController,
    middleware: contextModule.middlewares.workspaceContextMiddleware,
  }),
);
app.use(
  "/api/v1/workspace/models",
  createWorkspaceModelRoutes({
    workspaceModelController: workspaceModelModule.workspaceModelController,
    middleware: workspaceModelModule.contextMiddleware,
  }),
);

app.use("/api/auth", authRoutes);

app.use(
  "/api/v1/admin/auth",
  createAdminAuthRoutes({
    adminAuthController: adminAuthModule.adminAuthController,
    requirePlatformRoleUseCase: adminModule.requirePlatformRoleUseCase,
    userRepository,
    jwtService,
  }),
);

app.use(
  "/api/v1/admin",
  createAdminRoutes(
    adminModule.adminController,
    adminModule.userRepository,
    adminModule.getUserPermissionsUseCase,
    jwtService,
    contextModule.workspaceMemberPermissionRepository,
    organizationMemberModule.organizationMemberRepository,
    rbacRepository,
  ),
);

app.use(
  "/api/v1/profile",
  createProfileRoutes({
    profileController: profileModule.profileController,
    authMiddleware,
  }),
);

app.use(
  "/api/chat",
  createChatRoutes({
    middleware: authMiddleware,
  }),
);

app.use(
  "/api/v1/projects",
  createProjectRoutes(
    projectModule.projectController,
    contextModule.middlewares.workspaceContextMiddleware,
    adminModule.getUserPermissionsUseCase,
    contextModule.workspaceMemberPermissionRepository,
    organizationMemberModule.organizationMemberRepository,
    rbacRepository,
  ),
);

app.use(
  "/api/v1/project-members",
  createProjectMemberRoutes(projectMemberModule.projectMemberController),
);

app.use(
  "/api/v1/agent-tools",
  createAgentToolRoutes(agentToolModule.agentToolController, authMiddleware),
);

app.use(
  "/api/v1/agents",
  createAgentRoutes(
    agentModule.agentController,
    authMiddleware,
    contextModule.middlewares.workspaceContextMiddleware,
    adminModule.getUserPermissionsUseCase,
    contextModule.workspaceMemberPermissionRepository,
    organizationMemberModule.organizationMemberRepository,
    rbacRepository,
  ),
);

app.use(
  "/api/v1/projects/:projectId/knowledge",
  createKnowledgeSourceRoutes(
    knowledgeModule.knowledgeSourceController,
    authMiddleware,
    contextModule.middlewares.workspaceContextMiddleware,
    adminModule.getUserPermissionsUseCase,
    contextModule.workspaceMemberPermissionRepository,
    organizationMemberModule.organizationMemberRepository,
    rbacRepository,
  ),
);

app.use(
  "/api/v1/organizations",
  createOrganizationRoutes(
    organizationModule.organizationController,
    authMiddleware,
  ),
);

app.use(
  "/api/v1/organization-invitations",
  createOrganizationInvitationRoutes(
    organizationInvitationModule.organizationInvitationController,
    authMiddleware,
  ),
);

app.use(
  "/api/v1/organization-members",
  createOrganizationMemberRoutes(
    organizationMemberModule.organizationMemberController,
    authMiddleware,
  ),
);

app.use(
  "/api/v1/organizations",
  createAISettingsRoutes({
    aiSettingsController: aiSettingsModule.aiSettingsController,
    middleware: authMiddleware,
  }),
);

app.use(
  "/api/v1/workspace/members",
  createWorkspaceMemberRoutes({
    workspaceMemberController: workspaceMemberModule.workspaceMemberController,
    middleware: workspaceMemberModule.contextMiddleware,
  }),
);

app.use(
  "/api/v1/workspace/dashboard",
  createWorkspaceDashboardRoutes({
    workspaceDashboardController:
      workspaceDashboardModule.workspaceDashboardController,
    middleware: workspaceDashboardModule.contextMiddleware,
  }),
);

app.use(
  "/api/public/chat",
  createPublicChatRoutes({
    controller: publicChatModule.publicChatController,
  }),
);

app.use(errorMiddleware);
export default app;
