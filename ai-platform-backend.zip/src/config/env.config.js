import dotenv from "dotenv";

dotenv.config();

const envConfig = {
  port: Number(process.env.PORT || 3000),

  database: {
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT),
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE,
  },

  jwt: {
    secret: process.env.JWT_SECRET,
    accessExpiresIn: process.env.JWT_ACCESS_EXPIRES_IN || "1h",
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || "7d",
    refreshExpiresDays: Number(process.env.JWT_REFRESH_EXPIRES_DAYS || 7),
  },

  ai: {
    provider: process.env.AI_PROVIDER,
    rag: {
      noContextMessage: process.env.AI_RAG_NO_CONTEXT_MESSAGE,
      similarityThreshold: Number(
        process.env.AI_RAG_SIMILARITY_THRESHOLD || 0.7,
      ),
      systemPrompt: process.env.AI_RAG_SYSTEM_PROMPT,
      topK: Number(process.env.AI_RAG_TOP_K || 5),
    },
    ollama: {
      baseUrl: process.env.OLLAMA_BASE_URL,
      model: process.env.OLLAMA_MODEL,
      think: process.env.OLLAMA_THINK === "true",
    },
  },

  email: {
    resendApiKey: process.env.RESEND_API_KEY,
    from: process.env.EMAIL_FROM,
  },

  frontend: {
    url: process.env.FRONTEND_URL,
  },

  security: {
    agentToolEncryptionKey: process.env.AGENT_TOOL_ENCRYPTION_KEY,
    apiKeyEncryptionSecret: process.env.API_KEY_ENCRYPTION_SECRET,
    adminSetupToken: process.env.ADMIN_SETUP_TOKEN,
  },
};

export default envConfig;
