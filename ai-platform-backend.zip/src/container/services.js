import { AppDataSource } from "../database/datasource.js";
import { JwtService, PasswordService } from "../common/security/index.js";
import { createAIModelModule } from "../features/platform/ai-models/di.js";
import { createOrganizationModelAccessModule } from "../features/platform/organization-model-access/di.js";
import { createPlatformApiKeysModule } from "../features/platform/api-keys/di.js";
import { AuthService } from "../features/auth/service/auth.service.js";
import { ConversationService } from "../features/conversation/service/conversation.service.js";
import { PostgresUserRepository } from "../features/auth/repository/postgres/postgres-user.repository.js";
import { PostgresConversationRepository } from "../features/conversation/repository/postgres/postgres-conversation.repository.js";
import { PostgresMessageRepository } from "../features/message/repository/postgres/postgres-message.repository.js";
import { ProjectRepositoryImpl } from "../features/project/infrastructure/repositories/project.repository.impl.js";
import { ProjectMemberRepositoryImpl } from "../features/project-member/infrastructure/repositories/project-member.repository.impl.js";
import { createOrganizationModule } from "../features/organization/di.js";
import { createOrganizationMemberModule } from "../features/organization-member/di.js";
import { createOrganizationInvitationModule } from "../features/organization-invitations/di.js";
import { createProjectMemberModule } from "../features/project-member/di.js";
import { createProjectModule } from "../features/project/di.js";
import { createAgentModule } from "../features/agent/di.js";
import { createProfileModule } from "../features/profile/di.js";
import { createAdminModule } from "../features/admin/di.js";
import { createAdminAuthModule } from "../features/admin/admin-auth/di.js";
import { AIContextService } from "../features/ai-context/service/ai-context.service.js";
import { createAIProviderFactory } from "../providers/provider.factory.js";
import { PromptBuilder } from "../features/ai-context/builder/prompt.builder.js";
import { RbacDataSource } from "../features/rbac/infrastructure/datasource/rbac.datasource.js";
import { RbacRepositoryImpl } from "../features/rbac/infrastructure/repositories/rbac.repository.impl.js";
import { GetUserPermissionsUseCase } from "../features/rbac/application/use-cases/get-user-permissions.usecase.js";
import { createContextModule } from "../features/shared/context/di.js";
import { createCompanyProfileModule } from "../features/workspace/company/di.js";
import { createWorkspaceSettingsModule } from "../features/workspace/settings/di.js";
import { createWorkspaceMemberModule } from "../features/workspace/members/di.js";
import { createWorkspaceDashboardModule } from "../features/workspace/dashboard/di.js";
import { createWorkspaceModelModule } from "../features/workspace/models/di.js";
import { createPublicChatModule } from "../features/public-chat/di.js";
import { createAISettingsModule } from "../features/organization/ai-settings/di.js";
import { createKnowledgeModule } from "../features/knowledge/di.js";
import { AgentToolRepositoryImpl } from "../features/agent-tool/infrastructure/repositories/agent-tool.repository.impl.js";
import { createAgentToolModule } from "../features/agent-tool/di.js";
import { createWorkspaceApiKeysModule } from "../features/workspace/api-keys/di.js";
import { createPlatformConfigModule } from "../features/platform/config/di.js";
import { createEmbeddingProviderFactory } from "../providers/embeddings/embedding.provider.factory.js";
import { createEmailService } from "../features/notification/index/index.js";
import { TokenHashService } from "../common/security/token-hash.service.js";

import { OrganizationRepositoryImpl } from "../features/organization/infrastructure/repositories/organization.repository.impl.js";

const promptBuilder = new PromptBuilder();
export const jwtService = new JwtService();
const tokenHashService = new TokenHashService();
const passwordService = new PasswordService();
const aiModelModule = createAIModelModule({
  dataSource: AppDataSource,
});
const userRepository = new PostgresUserRepository(AppDataSource);
const conversationRepository = new PostgresConversationRepository(
  AppDataSource,
);
const messageRepository = new PostgresMessageRepository();
const projectRepository = new ProjectRepositoryImpl(AppDataSource);
const projectMemberRepository = new ProjectMemberRepositoryImpl(AppDataSource);
const agentToolRepository = new AgentToolRepositoryImpl(AppDataSource);
const rbacDataSource = new RbacDataSource();
const rbacRepository = new RbacRepositoryImpl(rbacDataSource);
const getUserPermissionsUseCase = new GetUserPermissionsUseCase(rbacRepository);
const organizationMemberModule = createOrganizationMemberModule();

const companyProfileModule = createCompanyProfileModule({
  dataSource: AppDataSource,
  contextMiddleware: null,
});

const workspaceSettingsModule = createWorkspaceSettingsModule({
  dataSource: AppDataSource,
});

const workspaceApiKeysModule = createWorkspaceApiKeysModule({
  dataSource: AppDataSource,
});

const platformApiKeysModule = createPlatformApiKeysModule({
  dataSource: AppDataSource,
});

const platformConfigModule = createPlatformConfigModule({
  dataSource: AppDataSource,
});

const embeddingProviderFactory = createEmbeddingProviderFactory({
  getPlatformConfigUseCase: platformConfigModule.getPlatformConfigUseCase,
});

const emailService = createEmailService({
  getPlatformConfigUseCase: platformConfigModule.getPlatformConfigUseCase,
});

const aiProviderFactory = createAIProviderFactory({
  getPlatformApiKeyValueUseCase:
    platformApiKeysModule.getPlatformApiKeyValueUseCase,

  getPlatformConfigUseCase: platformConfigModule.getPlatformConfigUseCase,
});

const aiSettingsModule = createAISettingsModule({
  dataSource: AppDataSource,
});

const organizationModelAccessModule = createOrganizationModelAccessModule({
  dataSource: AppDataSource,
});

const organizationRepository = new OrganizationRepositoryImpl(AppDataSource);

const organizationInvitationModule = createOrganizationInvitationModule({
  dataSource: AppDataSource,
  organizationRepository,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
  userRepository,
  passwordService,
  rbacRepository,
});

const organizationModule = createOrganizationModule({
  companyProfileRepository: companyProfileModule.companyProfileRepository,
  workspaceSettingsRepository:
    workspaceSettingsModule.workspaceSettingsRepository,
  userRepository,
  emailService,
});

const workspaceMemberModule = createWorkspaceMemberModule({
  dataSource: AppDataSource,
  userRepository,
  organizationRepository: organizationModule.organizationRepository,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
  organizationInvitationRepository:
    organizationInvitationModule.organizationInvitationRepository,
  organizationInvitationPermissionRepository:
    organizationInvitationModule.organizationInvitationPermissionRepository,
  contextMiddleware: null,
  emailService,
});

const workspaceModelModule = createWorkspaceModelModule({
  dataSource: AppDataSource,
  contextMiddleware: null,
});

const projectMemberModule = createProjectMemberModule({
  projectRepository,
  projectMemberRepository,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
});

const knowledgeModule = createKnowledgeModule({
  dataSource: AppDataSource,
  checkProjectAccessUseCase: projectMemberModule.checkProjectAccessUseCase,
  aiModelRepository: aiModelModule.aiModelRepository,
  getPlatformConfigUseCase: platformConfigModule.getPlatformConfigUseCase,
  embeddingProviderFactory,
});

const projectModule = createProjectModule({
  dataSource: AppDataSource,
  projectRepository,
  organizationRepository: organizationModule.organizationRepository,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
  projectMemberRepository: projectMemberModule.projectMemberRepository,
  checkProjectAccessUseCase: projectMemberModule.checkProjectAccessUseCase,
});

const agentModule = createAgentModule({
  dataSource: AppDataSource,
  projectRepository,
  checkProjectAccessUseCase: projectMemberModule.checkProjectAccessUseCase,
  organizationModelAccessRepository:
    organizationModelAccessModule.organizationModelAccessRepository,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
});

const agentToolModule = createAgentToolModule({
  agentRepository: agentModule.agentRepository,
  agentToolRepository,
  workspaceApiKeyRepository: workspaceApiKeysModule.workspaceApiKeyRepository,
  encryptionService: workspaceApiKeysModule.encryptionService,
  projectRepository,
  checkProjectAccessUseCase: projectMemberModule.checkProjectAccessUseCase,
});

const publicChatModule = createPublicChatModule({
  agentRepository: agentModule.agentRepository,
});

const profileModule = createProfileModule({
  userRepository,
  organizationRepository: organizationModule.organizationRepository,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
  projectRepository,
  projectMemberRepository,
  workspaceMemberPermissionRepository:
    workspaceMemberModule.workspaceMemberPermissionRepository,
  rbacRepository,
});

const adminAuthModule = createAdminAuthModule({
  dataSource: AppDataSource,
  jwtService,
  passwordService,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
  organizationRepository: organizationModule.organizationRepository,
  workspaceMemberPermissionRepository:
    workspaceMemberModule.workspaceMemberPermissionRepository,
  rbacRepository,
  getPlatformConfigUseCase: platformConfigModule.getPlatformConfigUseCase,
  tokenHashService,
});

const adminModule = createAdminModule({
  dataSource: AppDataSource,
  userRepository,
  createAdminUseCase: adminAuthModule.createAdminUseCase,
  getUserPermissionsUseCase,
});

const contextModule = createContextModule({
  dataSource: AppDataSource,
  userRepository,
  organizationRepository: organizationModule.organizationRepository,
  projectRepository,
  agentRepository: agentModule.agentRepository,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
  projectMemberRepository: projectMemberModule.projectMemberRepository,
  getUserPermissionsUseCase,
  jwtService,
  rbacRepository,
});

const workspaceDashboardModule = createWorkspaceDashboardModule({
  organizationRepository: organizationModule.organizationRepository,
  projectRepository,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
  agentRepository: agentModule.agentRepository,
  conversationRepository,
  requireWorkspaceAccess: contextModule.middlewares.workspaceContextMiddleware,
});

organizationModule.createOrganizationUseCase.organizationInvitationRepository =
  organizationInvitationModule.organizationInvitationRepository;

companyProfileModule.contextMiddleware =
  contextModule.middlewares.workspaceContextMiddleware;

workspaceSettingsModule.contextMiddleware =
  contextModule.middlewares.workspaceContextMiddleware;

workspaceMemberModule.contextMiddleware =
  contextModule.middlewares.workspaceContextMiddleware;

workspaceModelModule.contextMiddleware =
  contextModule.middlewares.workspaceContextMiddleware;

const aiContextService = new AIContextService({
  userRepository,
  agentRepository: agentModule.agentRepository,
  projectRepository,
  projectMemberRepository: projectMemberModule.projectMemberRepository,
  organizationRepository: organizationModule.organizationRepository,
  organizationAISettingsRepository: aiSettingsModule.aiSettingsRepository,
  checkProjectAccessUseCase: projectMemberModule.checkProjectAccessUseCase,
  promptBuilder,
});

export const authService = new AuthService({
  userRepository,
  getUserPermissionsUseCase,
  organizationMemberRepository:
    organizationMemberModule.organizationMemberRepository,
  organizationRepository: organizationModule.organizationRepository,
  jwtService,
});

export const conversationService = new ConversationService({
  conversationRepository,
  messageRepository,
  agentRepository: agentModule.agentRepository,
  aiProviderFactory,
  aiContextService,
  checkProjectAccessUseCase: projectMemberModule.checkProjectAccessUseCase,
  knowledgeSearchService: knowledgeModule.knowledgeSearchService,
  agentToolRepository: agentToolModule.agentToolRepository,
  agentToolSchemaService: agentToolModule.agentToolSchemaService,
  agentToolExecutorService: agentToolModule.agentToolExecutorService,
  agentToolResolverService: agentToolModule.agentToolResolverService,
  getPlatformConfigUseCase: platformConfigModule.getPlatformConfigUseCase,
});
export {
  userRepository,
  aiModelModule,
  tokenHashService,
  rbacRepository,
  organizationModelAccessModule,
  organizationModule,
  organizationInvitationModule,
  organizationMemberModule,
  aiSettingsModule,
  projectModule,
  projectMemberModule,
  agentModule,
  agentToolModule,
  knowledgeModule,
  profileModule,
  adminModule,
  adminAuthModule,
  contextModule,
  companyProfileModule,
  workspaceSettingsModule,
  workspaceApiKeysModule,
  platformApiKeysModule,
  platformConfigModule,
  workspaceMemberModule,
  workspaceDashboardModule,
  workspaceModelModule,
  publicChatModule,
};
