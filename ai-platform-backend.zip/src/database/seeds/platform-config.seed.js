import "dotenv/config";

import { AppDataSource } from "../datasource.js";

import { PlatformConfigOrmEntity } from "../../features/platform/config/infrastructure/database/platform-config.orm-entity.js";

const configs = [
  {
    configKey: "AI_PROVIDER",
    configValue: process.env.AI_PROVIDER,
    isSecret: false,
    description: "AI provider used by platform",
  },

  {
    configKey: "OLLAMA_BASE_URL",
    configValue: process.env.OLLAMA_BASE_URL,
    isSecret: false,
    description: "Ollama server URL",
  },

  {
    configKey: "OLLAMA_MODEL",
    configValue: process.env.OLLAMA_MODEL,
    isSecret: false,
    description: "Default Ollama model",
  },

  {
    configKey: "OLLAMA_THINK",
    configValue: process.env.OLLAMA_THINK,
    isSecret: false,
    description: "Enable Ollama thinking",
  },

  {
    configKey: "AI_RAG_SYSTEM_PROMPT",
    configValue: process.env.AI_RAG_SYSTEM_PROMPT,
    isSecret: false,
    description: "RAG system prompt",
  },

  {
    configKey: "AI_RAG_NO_CONTEXT_MESSAGE",
    configValue: process.env.AI_RAG_NO_CONTEXT_MESSAGE,
    isSecret: false,
    description: "Message when no knowledge context found",
  },

  {
    configKey: "AI_RAG_SIMILARITY_THRESHOLD",
    configValue: process.env.AI_RAG_SIMILARITY_THRESHOLD,
    isSecret: false,
    description: "RAG similarity threshold",
  },

  {
    configKey: "AI_RAG_TOP_K",
    configValue: process.env.AI_RAG_TOP_K,
    isSecret: false,
    description: "RAG top K results",
  },

  {
    configKey: "EMAIL_FROM",
    configValue: process.env.EMAIL_FROM,
    isSecret: false,
    description: "Default sender email",
  },

  {
    configKey: "FRONTEND_URL",
    configValue: process.env.FRONTEND_URL,
    isSecret: false,
    description: "Frontend application URL",
  },
];

async function seed() {
  await AppDataSource.initialize();

  const repository = AppDataSource.getRepository(PlatformConfigOrmEntity);

  for (const config of configs) {
    if (!config.configValue) {
      continue;
    }

    const exists = await repository.findOne({
      where: {
        configKey: config.configKey,
      },
    });

    if (exists) {
      console.log(`Skipped ${config.configKey}`);

      continue;
    }

    await repository.save(config);

    console.log(`Created ${config.configKey}`);
  }

  await AppDataSource.destroy();
}

seed().catch((error) => {
  console.error(error);
  process.exit(1);
});
