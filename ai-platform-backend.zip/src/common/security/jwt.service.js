import jwt from "jsonwebtoken";
import envConfig from "../../config/env.config.js";

export class JwtService {
  generateAccessToken(payload) {
    return jwt.sign(payload, envConfig.jwt.secret, {
      expiresIn: envConfig.jwt.accessExpiresIn,
    });
  }

  generateRefreshToken(payload) {
    return jwt.sign(payload, envConfig.jwt.secret, {
      expiresIn: envConfig.jwt.refreshExpiresIn,
    });
  }

  verifyAccessToken(token) {
    return jwt.verify(token, envConfig.jwt.secret, {
      expiresIn: envConfig.jwt.accessExpiresIn,
    });
  }

  verifyRefreshToken(token) {
    return jwt.verify(token, envConfig.jwt.secret, {
      expiresIn: envConfig.jwt.refreshExpiresIn,
    });
  }
}
