import { WorkspaceModelRepository } from "../../domain/repositories/workspace-model.repository.js";

export class WorkspaceModelRepositoryImpl extends WorkspaceModelRepository {
  constructor(dataSource) {
    super();

    this.repository = dataSource.getRepository("OrganizationModelAccess");
  }

  async findAvailableModels(organizationId) {
    const accesses = await this.repository.find({
      where: {
        organizationId,
        aiModel: {
          status: "ACTIVE",
        },
      },
      relations: {
        aiModel: true,
      },
    });

    return accesses.map((access) => ({
      id: access.aiModel.id,
      provider: access.aiModel.provider,
      model: access.aiModel.model,
      displayName: access.aiModel.displayName,
      description: access.aiModel.description,
      status: access.aiModel.status,
    }));
  }
}
