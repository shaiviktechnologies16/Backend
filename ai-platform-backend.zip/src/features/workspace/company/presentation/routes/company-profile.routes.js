import { Router } from "express";

export function createCompanyProfileRoutes({
  companyProfileController,
  middleware,
}) {
  const router = Router();
  router.get("/", ...middleware, companyProfileController.get);
  router.put("/", ...middleware, companyProfileController.update);
  return router;
}
