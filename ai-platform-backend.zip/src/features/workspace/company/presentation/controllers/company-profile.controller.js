import { asyncHandler } from "../../../../../common/utils/asyncHandler.js";

export class CompanyProfileController {
  constructor({ getCompanyProfileUseCase, updateCompanyProfileUseCase }) {
    this.getCompanyProfileUseCase = getCompanyProfileUseCase;

    this.updateCompanyProfileUseCase = updateCompanyProfileUseCase;
  }

  get = asyncHandler(async (req, res) => {
    const organizationId = req.context.organization.id;

    const result = await this.getCompanyProfileUseCase.execute(organizationId);

    res.status(200).json({
      success: true,
      data: result,
    });
  });

  update = asyncHandler(async (req, res) => {
    const organizationId = req.context.organization.id;

    const requesterRole = req.context.membership.role;

    await this.updateCompanyProfileUseCase.execute(
      organizationId,
      req.body,
      requesterRole,
    );

    res.status(200).json({
      success: true,
      data: result,
    });
  });
}
