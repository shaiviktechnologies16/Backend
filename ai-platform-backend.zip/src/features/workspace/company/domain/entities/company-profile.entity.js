export class CompanyProfileEntity {
  constructor({
    id,
    organizationId,
    companyName,
    logo,
    website,
    description,
    createdAt,
    updatedAt,
  }) {
    this.id = id;
    this.organizationId = organizationId;
    this.companyName = companyName;
    this.logo = logo;
    this.website = website;
    this.description = description;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;

    Object.freeze(this);
  }
}
