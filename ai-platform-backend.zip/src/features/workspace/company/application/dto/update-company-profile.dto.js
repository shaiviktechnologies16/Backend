export class UpdateCompanyProfileDto {
  constructor({ companyName, logo, website, description }) {
    this.companyName = companyName;
    this.logo = logo;
    this.website = website;
    this.description = description;
  }
}
