import { AppError } from "../../../../../common/errors/AppError.js";

export class GetCompanyProfileUseCase {
  constructor({ companyProfileRepository }) {
    this.companyProfileRepository = companyProfileRepository;
  }

  async execute(organizationId) {
    const companyProfile =
      await this.companyProfileRepository.findByOrganizationId(organizationId);

    if (!companyProfile) {
      throw new AppError(
        "Company profile not found.",
        404,
        "COMPANY_PROFILE_NOT_FOUND",
      );
    }

    return companyProfile;
  }
}
