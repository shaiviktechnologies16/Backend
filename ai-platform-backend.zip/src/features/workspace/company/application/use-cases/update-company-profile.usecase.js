import { AppError } from "../../../../../common/errors/AppError.js";
import { OrganizationRole } from "../../../../organization/domain/constants/organization-role.js";

export class UpdateCompanyProfileUseCase {
  constructor({ companyProfileRepository }) {
    this.companyProfileRepository = companyProfileRepository;
  }

  async execute(organizationId, updateDto, requesterRole) {
    if (requesterRole !== OrganizationRole.OWNER) {
      throw new AppError(
        "Only owner can update company profile.",
        403,
        "COMPANY_PROFILE_UPDATE_NOT_ALLOWED",
      );
    }

    const companyProfile =
      await this.companyProfileRepository.findByOrganizationId(organizationId);

    if (!companyProfile) {
      throw new AppError(
        "Company profile not found.",
        404,
        "COMPANY_PROFILE_NOT_FOUND",
      );
    }

    return this.companyProfileRepository.update(companyProfile.id, {
      companyName: updateDto.companyName,
      logo: updateDto.logo,
      website: updateDto.website,
      description: updateDto.description,
    });
  }
}
