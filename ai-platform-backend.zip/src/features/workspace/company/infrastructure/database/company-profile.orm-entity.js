import { EntitySchema } from "typeorm";

export const CompanyProfileOrmEntity = new EntitySchema({
  name: "CompanyProfile",
  tableName: "company_profiles",

  columns: {
    id: {
      type: "uuid",
      primary: true,
      generated: "uuid",
    },

    organizationId: {
      name: "organization_id",
      type: "uuid",
      unique: true,
    },

    companyName: {
      name: "company_name",
      type: "varchar",
      length: 255,
    },

    logo: {
      type: "text",
      nullable: true,
    },

    website: {
      type: "varchar",
      length: 255,
      nullable: true,
    },

    description: {
      type: "text",
      nullable: true,
    },

    createdAt: {
      name: "created_at",
      type: "timestamp",
      createDate: true,
    },

    updatedAt: {
      name: "updated_at",
      type: "timestamp",
      updateDate: true,
    },
  },
});
