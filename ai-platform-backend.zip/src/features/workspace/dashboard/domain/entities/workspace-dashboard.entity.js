export class WorkspaceDashboardEntity {
  constructor({ overview, recentProjects = [], agents, conversations }) {
    this.overview = overview;
    this.recentProjects = recentProjects;
    this.agents = agents;
    this.conversations = conversations;
  }

  toJSON() {
    return {
      overview: this.overview,
      recentProjects: this.recentProjects,
      agents: this.agents,
      conversations: this.conversations,
    };
  }
}
