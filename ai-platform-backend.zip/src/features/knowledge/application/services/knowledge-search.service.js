import { AppError } from "../../../../common/errors/AppError.js";

export class KnowledgeSearchService {
  constructor({
    knowledgeChunkRepository,
    aiModelRepository,
    getPlatformConfigUseCase,
    embeddingProviderFactory,
  }) {
    this.knowledgeChunkRepository = knowledgeChunkRepository;
    this.aiModelRepository = aiModelRepository;
    this.getPlatformConfigUseCase = getPlatformConfigUseCase;
    this.embeddingProviderFactory = embeddingProviderFactory;
  }

  async search({ projectId, query, limit }) {
    if (!projectId) {
      throw new AppError("Project ID is required.", 400, "PROJECT_ID_REQUIRED");
    }

    if (!query?.trim()) {
      throw new AppError(
        "Search query is required.",
        400,
        "SEARCH_QUERY_REQUIRED",
      );
    }

    const configuredTopK = Number(
      await this.getPlatformConfigUseCase.getValue("AI_RAG_TOP_K"),
    );

    const configuredSimilarityThreshold = Number(
      await this.getPlatformConfigUseCase.getValue(
        "AI_RAG_SIMILARITY_THRESHOLD",
      ),
    );

    const topK = Number.isFinite(configuredTopK) ? configuredTopK : 5;

    const similarityThreshold = Number.isFinite(configuredSimilarityThreshold)
      ? configuredSimilarityThreshold
      : 0.7;

    const models = await this.aiModelRepository.findAll();

    const embeddingModel = models.find(
      (model) => model.capability === "EMBEDDING" && model.status === "ACTIVE",
    );

    if (!embeddingModel) {
      throw new AppError(
        "No active embedding model is configured.",
        503,
        "EMBEDDING_MODEL_NOT_CONFIGURED",
      );
    }

    const provider = this.embeddingProviderFactory.getProvider(
      embeddingModel.provider,
    );

    const [queryEmbedding] = await provider.embed([query.trim()], {
      model: embeddingModel.model,
    });

    if (!queryEmbedding) {
      throw new AppError(
        "Unable to generate query embedding.",
        500,
        "QUERY_EMBEDDING_FAILED",
      );
    }

    return await this.knowledgeChunkRepository.searchSimilar({
      projectId,
      embedding: queryEmbedding,
      limit: limit ?? topK,
      similarityThreshold,
    });
  }
}
