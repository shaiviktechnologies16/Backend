export function organizationInvitationTemplate({
  organizationName,
  inviterName,
  invitationUrl,
  role = "MEMBER",
  expiresInDays = 7,
}) {
  return {
    subject: `You're invited to join ${organizationName}`,

    html: `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<title>Organization Invitation</title>
</head>

<body style="margin:0;padding:0;background:#f8fafc;font-family:Arial,sans-serif;">

<table width="100%" cellpadding="0" cellspacing="0">
<tr>
<td align="center" style="padding:40px 20px;">

<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;padding:40px;">

<tr>
<td>

<h2 style="margin:0 0 24px;color:#111827;">
AI Platform
</h2>

<p style="font-size:16px;color:#374151;">
Hello,
</p>

<p style="font-size:16px;color:#374151;line-height:26px;">
<strong>${inviterName}</strong> has invited you to join
<strong>${organizationName}</strong> as a
<strong>${role}</strong>.
</p>

<p style="font-size:16px;color:#374151;line-height:26px;">
Click the button below to accept your invitation.
</p>

<div style="margin:36px 0;text-align:center;">
<a
href="${invitationUrl}"
style="
background:#2563eb;
color:#ffffff;
padding:14px 28px;
text-decoration:none;
border-radius:8px;
display:inline-block;
font-weight:600;
">
Accept Invitation
</a>
</div>

<p style="font-size:14px;color:#6b7280;">
This invitation expires in <strong>${expiresInDays} days</strong>.
</p>

<hr style="margin:32px 0;border:none;border-top:1px solid #e5e7eb;" />

<p style="font-size:13px;color:#9ca3af;">
If you weren't expecting this invitation, you can safely ignore this email.
</p>

</td>
</tr>

</table>

</td>
</tr>
</table>

</body>
</html>
`,
  };
}
