import { Conversation } from "../entity/conversation.entity.js";
import { Message } from "../../message/entity/message.entity.js";
import { MessageRole } from "../../../common/constants/message-role.js";
import { executeTransaction } from "../../../database/transaction.js";
import { AppError } from "../../../common/errors/AppError.js";

export class ConversationService {
  constructor({
    conversationRepository,
    messageRepository,
    agentRepository,
    aiProviderFactory,
    aiContextService,
    checkProjectAccessUseCase,
    knowledgeSearchService,
    agentToolRepository,
    agentToolSchemaService,
    agentToolExecutorService,
    agentToolResolverService,
    getPlatformConfigUseCase,
  }) {
    this.conversationRepository = conversationRepository;
    this.messageRepository = messageRepository;
    this.agentRepository = agentRepository;
    this.aiProviderFactory = aiProviderFactory;
    this.aiContextService = aiContextService;
    this.checkProjectAccessUseCase = checkProjectAccessUseCase;
    this.knowledgeSearchService = knowledgeSearchService;
    this.agentToolRepository = agentToolRepository;
    this.agentToolSchemaService = agentToolSchemaService;
    this.agentToolExecutorService = agentToolExecutorService;
    this.agentToolResolverService = agentToolResolverService;
    this.getPlatformConfigUseCase = getPlatformConfigUseCase;
  }

  async getAgent(userId, agentId = null, projectId = null) {
    let agent;

    if (agentId) {
      agent = await this.agentRepository.findById(agentId);

      if (!agent) {
        throw new AppError("Agent not found.", 404, "AGENT_NOT_FOUND");
      }

      if (projectId && agent.projectId !== projectId) {
        throw new AppError(
          "Agent does not belong to project.",
          403,
          "INVALID_PROJECT_ACCESS",
        );
      }

      await this.checkProjectAccessUseCase.execute({
        projectId: agent.projectId,
        userId,
      });
    } else {
      if (!projectId) {
        throw new AppError("Project ID is required.", 400, "PROJECT_REQUIRED");
      }

      agent = await this.agentRepository.findDefaultByProject(projectId);

      if (!agent) {
        throw new AppError(
          "Default agent not found.",
          404,
          "DEFAULT_AGENT_NOT_FOUND",
        );
      }

      await this.checkProjectAccessUseCase.execute({
        projectId,
        userId,
      });
    }

    return agent;
  }

  async getConversation(userId, conversationId, manager = null) {
    const conversation = await this.conversationRepository.findById(
      conversationId,
      manager,
    );

    if (!conversation) {
      throw new AppError(
        "Conversation not found.",
        404,
        "CONVERSATION_NOT_FOUND",
      );
    }

    await this.checkProjectAccessUseCase.execute({
      projectId: conversation.projectId,
      userId,
    });

    return conversation;
  }

  async createConversation(
    userId,
    { title = "New Conversation", agentId = null, projectId = null } = {},
  ) {
    const agent = await this.getAgent(userId, agentId, projectId);

    const conversation = new Conversation({
      userId,
      projectId: agent.projectId,
      agentId: agent.id,
      title,
    });

    return await this.conversationRepository.create(conversation);
  }

  async getConversationById(userId, conversationId) {
    return await this.getConversation(userId, conversationId);
  }

  async getConversations(userId, projectId) {
    if (!projectId) {
      throw new AppError("Project ID is required.", 400, "PROJECT_ID_REQUIRED");
    }

    await this.checkProjectAccessUseCase.execute({
      projectId,
      userId,
    });

    return await this.conversationRepository.findAllByProject(projectId);
  }

  async buildRagSystemMessage({ context, projectId, query, isPublic = false }) {
    const systemMessage = this.aiContextService.buildSystemMessage(context);

    const knowledgeResults = await this.knowledgeSearchService.search({
      projectId,
      query,
    });

    const ragSystemPrompt = await this.getPlatformConfigUseCase.getValue(
      "AI_RAG_SYSTEM_PROMPT",
    );

    const noContextMessage = await this.getPlatformConfigUseCase.getValue(
      "AI_RAG_NO_CONTEXT_MESSAGE",
    );

    const knowledgeContext = knowledgeResults
      .map((result, index) => {
        return `[Knowledge ${index + 1}]
${result.content}`;
      })
      .join("\n\n");

    return {
      message: {
        role: MessageRole.SYSTEM,
        content: `${systemMessage.content}

${ragSystemPrompt}

Knowledge Context:
${knowledgeContext || noContextMessage}`,
      },
      sources: knowledgeResults.map((result) => ({
        knowledgeSourceId: result.knowledgeSourceId,
        knowledgeSourceName: result.knowledgeSourceName,
        chunkId: result.id,
        chunkIndex: result.chunkIndex,
        similarity: result.similarity,
      })),
    };
  }
  async getAgentTools(agentId) {
    const tools = await this.agentToolRepository.findByAgentId(agentId);

    return {
      tools,
      schemas: this.agentToolSchemaService.toOllamaTools(tools),
    };
  }

  async sendMessage(
    userId,
    conversationId,
    content,
    agentId = null,
    projectId = null,
  ) {
    let conversation;
    let agent;

    await executeTransaction(async (queryRunner) => {
      const manager = queryRunner.manager;

      if (conversationId) {
        conversation = await this.getConversation(
          userId,
          conversationId,
          manager,
        );

        agent = await this.agentRepository.findById(conversation.agentId);

        if (!agent) {
          throw new AppError("Agent not found.", 404, "AGENT_NOT_FOUND");
        }
      } else {
        agent = await this.getAgent(userId, agentId, projectId);

        conversation = new Conversation({
          userId,
          projectId: agent.projectId,
          agentId: agent.id,
          title: "New Conversation",
        });

        conversation = await this.conversationRepository.create(
          conversation,
          manager,
        );
      }

      const userMessage = new Message({
        conversationId: conversation.id,
        role: MessageRole.USER,
        content,
      });

      await this.messageRepository.create(userMessage, manager);
    });

    const aiProvider = await this.aiProviderFactory.getProvider();
    const history = await this.messageRepository.findRecentByConversationId(
      conversation.id,
      aiProvider.maxContextMessages,
    );

    const messages = history.map((message) => ({
      role: message.role,
      content: message.content,
    }));

    const context = await this.aiContextService.build({
      userId,
      agentId: agent.id,
      conversation,
    });

    const ragResult = await this.buildRagSystemMessage({
      context,
      projectId: conversation.projectId,
      query: content,
    });

    messages.unshift(ragResult.message);
    const agentTools = await this.getAgentTools(agent.id);

    const toolMessages = [...messages];

    let response = await aiProvider.chat(toolMessages, {
      model: agent.model,
      temperature: agent.temperature,
      maxTokens: agent.maxTokens,
      tools: agentTools.schemas,
    });

    let toolIterations = 0;
    const maxToolIterations = 5;

    while (
      response.message?.tool_calls?.length > 0 &&
      toolIterations < maxToolIterations
    ) {
      toolIterations++;

      const assistantMessage = {
        role: "assistant",
        content: response.message.content ?? "",
        tool_calls: response.message.tool_calls,
      };

      toolMessages.push(assistantMessage);

      for (const toolCall of response.message.tool_calls) {
        const toolName = toolCall.function?.name;
        const toolArguments = toolCall.function?.arguments ?? {};

        const tool = await this.agentToolResolverService.resolve(
          agent.id,
          toolName,
        );

        const result = await this.agentToolExecutorService.execute(
          tool,
          toolArguments,
        );

        toolMessages.push({
          role: "tool",
          content: typeof result === "string" ? result : JSON.stringify(result),
        });
      }

      response = await aiProvider.chat(toolMessages, {
        model: agent.model,
        temperature: agent.temperature,
        maxTokens: agent.maxTokens,
        tools: agentTools.schemas,
      });
    }

    if (response.message?.tool_calls?.length > 0) {
      throw new AppError(
        "Maximum tool execution limit reached.",
        400,
        "TOOL_ITERATION_LIMIT",
      );
    }

    const reply = response.message?.content ?? "";

    await executeTransaction(async (queryRunner) => {
      const manager = queryRunner.manager;

      const assistantMessage = new Message({
        conversationId: conversation.id,
        role: MessageRole.ASSISTANT,
        content: reply,
      });

      await this.messageRepository.create(assistantMessage, manager);
    });

    return {
      conversationId: conversation.id,
      agentId: conversation.agentId,
      reply,
      sources: ragResult.sources,
    };
  }

  async *streamMessage(
    userId,
    conversationId,
    content,
    agentId = null,
    projectId = null,
  ) {
    let conversation;
    let agent;

    await executeTransaction(async (queryRunner) => {
      const manager = queryRunner.manager;

      if (conversationId) {
        conversation = await this.getConversation(
          userId,
          conversationId,
          manager,
        );

        agent = await this.getAgent(
          userId,
          conversation.agentId,
          conversation.projectId,
        );
      } else {
        agent = await this.getAgent(userId, agentId, projectId);

        conversation = new Conversation({
          userId,
          projectId: agent.projectId,
          agentId: agent.id,
          title: "New Conversation",
        });

        conversation = await this.conversationRepository.create(
          conversation,
          manager,
        );
      }

      const userMessage = new Message({
        conversationId: conversation.id,
        role: MessageRole.USER,
        content,
      });

      await this.messageRepository.create(userMessage, manager);
    });

    const aiProvider = await this.aiProviderFactory.getProvider();
    const history = await this.messageRepository.findRecentByConversationId(
      conversation.id,
      aiProvider.maxContextMessages,
    );

    const messages = history.map((message) => ({
      role: message.role,
      content: message.content,
    }));

    const context = await this.aiContextService.build({
      userId,
      agentId: agent.id,
      conversation,
    });

    const ragResult = await this.buildRagSystemMessage({
      context,
      projectId: conversation.projectId,
      query: content,
    });

    messages.unshift(ragResult.message);

    const agentTools = await this.agentToolRepository.findByAgentId(agent.id);

    const tools = agentTools
      .filter((tool) => tool.enabled)
      .map((tool) => ({
        type: "function",
        function: {
          name: tool.name,
          description: tool.description,
          parameters: tool.configuration?.parameters ?? {
            type: "object",
            properties: {},
            required: [],
          },
        },
      }));

    let reply = "";
    let currentMessages = [...messages];

    let toolIterations = 0;
    const maxToolIterations = 5;

    yield {
      type: "conversation",
      conversationId: conversation.id,
    };

    yield {
      type: "sources",
      sources: ragResult.sources,
    };

    while (toolIterations < maxToolIterations) {
      let toolCalls = [];
      let streamedText = "";

      for await (const event of aiProvider.stream(currentMessages, {
        model: agent.model,
        temperature: agent.temperature,
        maxTokens: agent.maxTokens,
        tools,
      })) {
        if (event.type === "token") {
          streamedText += event.content;
          reply += event.content;

          yield {
            type: "token",
            content: event.content,
          };

          continue;
        }

        if (event.type === "tool_calls") {
          toolCalls.push(...event.toolCalls);
        }
      }

      if (toolCalls.length === 0) {
        break;
      }

      currentMessages.push({
        role: "assistant",
        content: streamedText,
        tool_calls: toolCalls,
      });

      for (const toolCall of toolCalls) {
        const toolName = toolCall.function?.name;

        const toolArguments = toolCall.function?.arguments ?? {};

        const tool = await this.agentToolResolverService.resolve(
          agent.id,
          toolName,
        );

        yield {
          type: "tool_call",
          toolName,
        };

        const result = await this.agentToolExecutorService.execute(
          tool,
          toolArguments,
        );

        const toolResult =
          typeof result === "string" ? result : JSON.stringify(result);

        currentMessages.push({
          role: "tool",
          content: toolResult,
        });

        yield {
          type: "tool_result",
          toolName,
          content: toolResult,
        };
      }

      toolIterations++;
    }

    if (toolIterations >= maxToolIterations) {
      throw new AppError(
        "Maximum tool execution limit reached.",
        400,
        "TOOL_ITERATION_LIMIT",
      );
    }

    await executeTransaction(async (queryRunner) => {
      const manager = queryRunner.manager;

      const assistantMessage = new Message({
        conversationId: conversation.id,
        role: MessageRole.ASSISTANT,
        content: reply,
      });

      await this.messageRepository.create(assistantMessage, manager);
    });

    yield {
      type: "done",
    };
  }

  async sendPublicMessage(
    publicKey,
    content,
    visitorId,
    conversationId = null,
  ) {
    let conversation;
    let agent;

    await executeTransaction(async (queryRunner) => {
      const manager = queryRunner.manager;

      agent = await this.agentRepository.findByPublicKey(publicKey);

      if (!agent) {
        throw new AppError(
          "Public agent not found.",
          404,
          "PUBLIC_AGENT_NOT_FOUND",
        );
      }

      if (agent.visibility !== "PUBLIC") {
        throw new AppError("Agent is not public.", 403, "AGENT_NOT_PUBLIC");
      }

      if (conversationId) {
        conversation = await this.conversationRepository.findById(
          conversationId,
          manager,
        );

        if (!conversation) {
          throw new AppError(
            "Conversation not found.",
            404,
            "CONVERSATION_NOT_FOUND",
          );
        }

        if (conversation.agentId !== agent.id) {
          throw new AppError(
            "Conversation does not belong to this agent.",
            403,
            "INVALID_PUBLIC_CONVERSATION",
          );
        }

        if (conversation.visitorId !== visitorId) {
          throw new AppError(
            "Conversation does not belong to this visitor.",
            403,
            "INVALID_PUBLIC_CONVERSATION",
          );
        }
      } else {
        conversation = new Conversation({
          userId: null,
          visitorId,
          projectId: agent.projectId,
          agentId: agent.id,
          title: "New Conversation",
        });

        conversation = await this.conversationRepository.create(
          conversation,
          manager,
        );
      }

      const userMessage = new Message({
        conversationId: conversation.id,
        role: MessageRole.USER,
        content,
      });

      await this.messageRepository.create(userMessage, manager);
    });

    const aiProvider = await this.aiProviderFactory.getProvider();
    const history = await this.messageRepository.findRecentByConversationId(
      conversation.id,
      aiProvider.maxContextMessages,
    );

    const messages = history.map((message) => ({
      role: message.role,
      content: message.content,
    }));

    const context = await this.aiContextService.buildPublic({
      agentId: agent.id,
      conversation,
    });

    const ragResult = await this.buildRagSystemMessage({
      context,
      projectId: conversation.projectId,
      query: content,
      isPublic: true,
    });

    messages.unshift(ragResult.message);

    const agentTools = await this.agentToolRepository.findByAgentId(agent.id);

    const tools = agentTools
      .filter((tool) => tool.enabled)
      .map((tool) => ({
        type: "function",
        function: {
          name: tool.name,
          description: tool.description,
          parameters: tool.configuration?.parameters ?? {
            type: "object",
            properties: {},
            required: [],
          },
        },
      }));

    let currentMessages = [...messages];
    let reply = "";

    let toolIterations = 0;
    const maxToolIterations = 5;

    while (toolIterations < maxToolIterations) {
      const response = await aiProvider.chat(currentMessages, {
        model: agent.model,
        temperature: agent.temperature,
        maxTokens: agent.maxTokens,
        tools,
      });

      const toolCalls = response.message?.tool_calls ?? [];

      if (toolCalls.length === 0) {
        reply = response.message?.content ?? "";
        break;
      }

      currentMessages.push({
        role: "assistant",
        content: response.message?.content ?? "",
        tool_calls: toolCalls,
      });

      for (const toolCall of toolCalls) {
        const toolName = toolCall.function?.name;

        const toolArguments = toolCall.function?.arguments ?? {};

        const tool = await this.agentToolResolverService.resolve(
          agent.id,
          toolName,
        );

        const result = await this.agentToolExecutorService.execute(
          tool,
          toolArguments,
        );

        const toolResult =
          typeof result === "string" ? result : JSON.stringify(result);

        currentMessages.push({
          role: "tool",
          content: toolResult,
        });
      }

      toolIterations++;
    }

    if (toolIterations >= maxToolIterations && !reply) {
      throw new AppError(
        "Maximum tool execution limit reached.",
        400,
        "TOOL_ITERATION_LIMIT",
      );
    }

    await executeTransaction(async (queryRunner) => {
      const assistantMessage = new Message({
        conversationId: conversation.id,
        role: MessageRole.ASSISTANT,
        content: reply,
      });

      await this.messageRepository.create(
        assistantMessage,
        queryRunner.manager,
      );
    });

    return {
      conversationId: conversation.id,
      agentId: conversation.agentId,
      reply,
      sources: ragResult.sources,
    };
  }

  async *streamPublicMessage(
    publicKey,
    content,
    visitorId,
    conversationId = null,
  ) {
    let conversation;
    let agent;

    await executeTransaction(async (queryRunner) => {
      const manager = queryRunner.manager;

      agent = await this.agentRepository.findByPublicKey(publicKey);

      if (!agent) {
        throw new AppError(
          "Public agent not found.",
          404,
          "PUBLIC_AGENT_NOT_FOUND",
        );
      }

      if (agent.visibility !== "PUBLIC") {
        throw new AppError("Agent is not public.", 403, "AGENT_NOT_PUBLIC");
      }

      if (conversationId) {
        conversation = await this.conversationRepository.findById(
          conversationId,
          manager,
        );

        if (!conversation) {
          throw new AppError(
            "Conversation not found.",
            404,
            "CONVERSATION_NOT_FOUND",
          );
        }

        if (conversation.agentId !== agent.id) {
          throw new AppError(
            "Conversation does not belong to this agent.",
            403,
            "INVALID_PUBLIC_CONVERSATION",
          );
        }

        if (conversation.visitorId !== visitorId) {
          throw new AppError(
            "Conversation does not belong to this visitor.",
            403,
            "INVALID_PUBLIC_CONVERSATION",
          );
        }
      } else {
        conversation = new Conversation({
          userId: null,
          visitorId,
          projectId: agent.projectId,
          agentId: agent.id,
          title: "New Conversation",
        });

        conversation = await this.conversationRepository.create(
          conversation,
          manager,
        );
      }

      const userMessage = new Message({
        conversationId: conversation.id,
        role: MessageRole.USER,
        content,
      });

      await this.messageRepository.create(userMessage, manager);
    });

    const aiProvider = await this.aiProviderFactory.getProvider();
    const history = await this.messageRepository.findRecentByConversationId(
      conversation.id,
      aiProvider.maxContextMessages,
    );

    const messages = history.map((message) => ({
      role: message.role,
      content: message.content,
    }));

    const context = await this.aiContextService.buildPublic({
      agentId: agent.id,
      conversation,
    });

    const ragResult = await this.buildRagSystemMessage({
      context,
      projectId: conversation.projectId,
      query: content,
      isPublic: true,
    });

    messages.unshift(ragResult.message);

    const agentTools = await this.agentToolRepository.findByAgentId(agent.id);

    const tools = agentTools
      .filter((tool) => tool.enabled)
      .map((tool) => ({
        type: "function",
        function: {
          name: tool.name,
          description: tool.description,
          parameters: tool.configuration?.parameters ?? {
            type: "object",
            properties: {},
            required: [],
          },
        },
      }));

    let reply = "";
    let currentMessages = [...messages];

    let toolIterations = 0;
    const maxToolIterations = 5;

    yield {
      type: "conversation",
      conversationId: conversation.id,
    };

    yield {
      type: "sources",
      sources: ragResult.sources,
    };

    while (toolIterations < maxToolIterations) {
      let toolCalls = [];
      let streamedText = "";

      for await (const event of aiProvider.stream(currentMessages, {
        model: agent.model,
        temperature: agent.temperature,
        maxTokens: agent.maxTokens,
        tools,
      })) {
        if (event.type === "token") {
          streamedText += event.content;
          reply += event.content;

          yield {
            type: "token",
            content: event.content,
          };

          continue;
        }

        if (event.type === "tool_calls") {
          toolCalls.push(...event.toolCalls);
        }
      }

      if (toolCalls.length === 0) {
        break;
      }

      currentMessages.push({
        role: "assistant",
        content: streamedText,
        tool_calls: toolCalls,
      });

      for (const toolCall of toolCalls) {
        const toolName = toolCall.function?.name;

        const toolArguments = toolCall.function?.arguments ?? {};

        const tool = await this.agentToolResolverService.resolve(
          agent.id,
          toolName,
        );

        yield {
          type: "tool_call",
          toolName,
        };

        const result = await this.agentToolExecutorService.execute(
          tool,
          toolArguments,
        );

        const toolResult =
          typeof result === "string" ? result : JSON.stringify(result);

        currentMessages.push({
          role: "tool",
          content: toolResult,
        });

        yield {
          type: "tool_result",
          toolName,
          content: toolResult,
        };
      }

      toolIterations++;
    }

    if (toolIterations >= maxToolIterations) {
      throw new AppError(
        "Maximum tool execution limit reached.",
        400,
        "TOOL_ITERATION_LIMIT",
      );
    }

    await executeTransaction(async (queryRunner) => {
      const assistantMessage = new Message({
        conversationId: conversation.id,
        role: MessageRole.ASSISTANT,
        content: reply,
      });

      await this.messageRepository.create(
        assistantMessage,
        queryRunner.manager,
      );
    });

    yield {
      type: "done",
    };
  }

  async getConversationMessages(userId, conversationId) {
    const conversation = await this.getConversation(userId, conversationId);

    const messages = await this.messageRepository.findByConversationId(
      conversation.id,
    );

    return {
      conversation,
      messages,
    };
  }

  async updateConversationTitle(userId, conversationId, title) {
    const conversation = await this.getConversation(userId, conversationId);

    conversation.updateTitle(title);

    return await this.conversationRepository.update(conversation);
  }

  async deleteConversation(userId, conversationId) {
    const conversation = await this.getConversation(userId, conversationId);

    await this.conversationRepository.delete(conversation.id);
  }
}
