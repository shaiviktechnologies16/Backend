import Joi from "joi";

export const createOrganizationInvitationSchema = Joi.object({
  organizationId: Joi.string().uuid().required(),
  email: Joi.string().email().required(),
  role: Joi.string().valid("OWNER", "ADMIN", "MEMBER").required(),
});

export const acceptOrganizationInvitationSchema = Joi.object({
  name: Joi.string().min(2).max(100).required(),
  password: Joi.string().min(8).required(),
});
