import { Router } from "express";

import { validate } from "../../../../common/middleware/validate.middleware.js";

import {
  createOrganizationInvitationSchema,
  acceptOrganizationInvitationSchema,
} from "../validators/organization-invitation.validator.js";

const createOrganizationInvitationRoutes = (
  organizationInvitationController,
  authMiddleware,
) => {
  const router = Router();

  router.post(
    "/",
    authMiddleware,
    validate(createOrganizationInvitationSchema),
    organizationInvitationController.createInvitation,
  );

  router.get("/:token", organizationInvitationController.validateInvitation);

  router.post(
    "/:token/accept",
    validate(acceptOrganizationInvitationSchema),
    organizationInvitationController.acceptInvitation,
  );

  return router;
};

export default createOrganizationInvitationRoutes;
