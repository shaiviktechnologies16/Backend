import { InvitationStatus } from "../../domain/constants/invitation-status.js";

export class ValidateOrganizationInvitationUseCase {
  constructor({ organizationInvitationRepository, organizationRepository }) {
    this.organizationInvitationRepository = organizationInvitationRepository;

    this.organizationRepository = organizationRepository;
  }

  async execute(token) {
    // 1. Find invitation
    const invitation =
      await this.organizationInvitationRepository.findByToken(token);

    if (!invitation) {
      throw new Error("Invitation not found.");
    }

    // 2. Check invitation status
    if (invitation.status !== InvitationStatus.PENDING) {
      throw new Error("Invitation is no longer valid.");
    }

    // 3. Check expiration
    if (invitation.isExpired()) {
      invitation.expire();

      await this.organizationInvitationRepository.update(invitation);

      throw new Error("Invitation has expired.");
    }

    // 4. Load organization
    const organization = await this.organizationRepository.findById(
      invitation.organizationId,
    );

    if (!organization) {
      throw new Error("Organization not found.");
    }

    // 5. Return data for frontend
    return {
      organization: {
        id: organization.id,
        name: organization.name,
        slug: organization.slug,
        logo: organization.logo,
      },
      invitation: {
        email: invitation.email,
        role: invitation.role,
        expiresAt: invitation.expiresAt,
      },
    };
  }
}
