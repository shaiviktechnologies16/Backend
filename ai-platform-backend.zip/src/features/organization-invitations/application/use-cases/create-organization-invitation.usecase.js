import crypto from "crypto";

import { OrganizationInvitationEntity } from "../../domain/entities/organization-invitation.entity.js";
import { InvitationStatus } from "../../domain/constants/invitation-status.js";

export class CreateOrganizationInvitationUseCase {
  constructor({ organizationRepository, organizationInvitationRepository }) {
    this.organizationRepository = organizationRepository;
    this.organizationInvitationRepository = organizationInvitationRepository;
  }

  async execute({ organizationId, email, role, createdBy }) {
    // 1. Check organization exists
    const organization =
      await this.organizationRepository.findById(organizationId);

    if (!organization) {
      throw new Error("Organization not found.");
    }

    // 2. Normalize email
    const normalizedEmail = email.trim().toLowerCase();

    // 3. Prevent duplicate pending invitation
    const existingInvitation =
      await this.organizationInvitationRepository.findPendingByOrganizationAndEmail(
        organizationId,
        normalizedEmail,
      );

    if (existingInvitation) {
      throw new Error("A pending invitation already exists for this email.");
    }

    // 4. Generate secure invitation token
    const token = crypto.randomBytes(32).toString("hex");

    // 5. Create invitation entity
    const invitation = new OrganizationInvitationEntity({
      organizationId,
      email: normalizedEmail,
      role,
      token,
      status: InvitationStatus.PENDING,

      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),

      createdBy,
    });

    // 6. Save invitation
    const createdInvitation =
      await this.organizationInvitationRepository.create(invitation);

    // 7. TODO
    // Email service will be integrated later.

    return createdInvitation;
  }
}
