import Joi from "joi";

const httpParameterSchema = Joi.object({
  type: Joi.string().valid("object").required(),
  properties: Joi.object().required(),
  required: Joi.array().items(Joi.string()).optional(),
}).required();

const httpConfigurationSchema = Joi.object({
  method: Joi.string()
    .valid("GET", "POST", "PUT", "PATCH", "DELETE")
    .required(),

  url: Joi.string().uri().required(),

  headers: Joi.object().pattern(Joi.string(), Joi.string()).default({}),

  parameters: httpParameterSchema.required(),
}).required();

export const createAgentToolSchema = Joi.object({
  name: Joi.string().trim().min(1).max(100).required(),

  description: Joi.string().trim().min(1).max(2000).required(),

  type: Joi.string().valid("HTTP").required(),

  credentialId: Joi.string().uuid().allow(null).optional(),

  configuration: Joi.when("type", {
    is: "HTTP",
    then: httpConfigurationSchema.required(),
    otherwise: Joi.forbidden(),
  }),
});

export const updateAgentToolSchema = Joi.object({
  name: Joi.string().trim().min(1).max(100).optional(),

  description: Joi.string().trim().min(1).max(2000).optional(),

  type: Joi.string().valid("HTTP").optional(),

  credentialId: Joi.string().uuid().allow(null).optional(),

  configuration: httpConfigurationSchema.optional(),

  enabled: Joi.boolean().optional(),
}).min(1);
