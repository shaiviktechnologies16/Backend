import crypto from "crypto";

import { AppError } from "../../../../common/errors/AppError.js";
import { generateSlug } from "../../../../common/utils/slug.js";

import { OrganizationRole } from "../../domain/constants/organization-role.js";
import { OrganizationStatus } from "../../domain/constants/organization-status.js";
import { OrganizationEntity } from "../../domain/entities/organization.entity.js";

import { OrganizationInvitationEntity } from "../../../organization-invitations/domain/entities/organization-invitation.entity.js";
import { InvitationStatus } from "../../../organization-invitations/domain/constants/invitation-status.js";

export class CreateOrganizationUseCase {
  constructor({
    dataSource,
    organizationRepository,
    organizationInvitationRepository,
    organizationInvitationPermissionRepository,
    permissionRepository,
    companyProfileRepository,
    workspaceSettingsRepository,
    userRepository,
    emailService,
  }) {
    this.dataSource = dataSource;
    this.organizationRepository = organizationRepository;
    this.organizationInvitationRepository = organizationInvitationRepository;
    this.organizationInvitationPermissionRepository =
      organizationInvitationPermissionRepository;
    this.permissionRepository = permissionRepository;
    this.companyProfileRepository = companyProfileRepository;
    this.workspaceSettingsRepository = workspaceSettingsRepository;
    this.userRepository = userRepository;
    this.emailService = emailService;
  }

  async execute({
    name,
    ownerEmail,
    logo = null,
    website = null,
    description = null,
    ownerId,
    createdBy,
  }) {
    const result = await this.dataSource.transaction(async (manager) => {
      const email = ownerEmail.trim().toLowerCase();

      const existingUser = await this.userRepository.findByEmail(
        email,
        manager,
      );

      if (existingUser) {
        throw new AppError(
          "A user already exists with this email.",
          409,
          "USER_EMAIL_ALREADY_EXISTS",
        );
      }

      const existingInvitation =
        await this.organizationInvitationRepository.findByEmail(email, manager);

      if (existingInvitation) {
        throw new AppError(
          "This owner email is already assigned to another organization.",
          409,
          "OWNER_EMAIL_ALREADY_EXISTS",
        );
      }

      const baseSlug = generateSlug(name);

      let slug = baseSlug;
      let counter = 1;

      while (await this.organizationRepository.findBySlug(slug, manager)) {
        slug = `${baseSlug}-${counter++}`;
      }

      const organization = new OrganizationEntity({
        name,
        slug,
        ownerId: null,
        logo,
        website,
        description,
        status: OrganizationStatus.ACTIVE,
      });

      const createdOrganization = await this.organizationRepository.create(
        organization,
        manager,
      );

      await this.companyProfileRepository.create(
        {
          organizationId: createdOrganization.id,
          companyName: createdOrganization.name,
          logo: createdOrganization.logo,
          website: createdOrganization.website,
          description: createdOrganization.description,
        },
        manager,
      );

      await this.workspaceSettingsRepository.create(
        {
          organizationId: createdOrganization.id,
          assistantName: "AI Assistant",
          assistantDescription: null,
          systemPrompt: null,
          themeConfig: {},
          featureFlags: {},
        },
        manager,
      );

      const invitation = new OrganizationInvitationEntity({
        organizationId: createdOrganization.id,
        email,
        role: OrganizationRole.OWNER,
        token: crypto.randomBytes(32).toString("hex"),
        status: InvitationStatus.PENDING,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        createdBy,
      });

      const createdInvitation =
        await this.organizationInvitationRepository.create(invitation, manager);

      const permissions = await this.permissionRepository.findAll();

      await this.organizationInvitationPermissionRepository.replacePermissions(
        createdInvitation.id,
        permissions.map((permission) => permission.id),
        manager,
      );

      return {
        organization: createdOrganization,
        invitation: createdInvitation,
        email,
      };
    });

    try {
      await this.emailService.sendOrganizationInvitation({
        email: result.email,
        organizationName: result.organization.name,
        inviterName: "Organization Admin",
        invitationToken: result.invitation.token,
        role: OrganizationRole.OWNER,
      });
    } catch (error) {
      console.error("Failed to send organization invitation email:", error);
    }

    return result.organization;
  }
}
