import { AppDataSource } from "../../database/datasource.js";

import { OrganizationRepositoryImpl } from "./infrastructure/repositories/organization.repository.impl.js";

import { CreateOrganizationUseCase } from "./application/use-cases/create-organization.usecase.js";
import { GetOrganizationUseCase } from "./application/use-cases/get-organization.usecase.js";
import { GetOrganizationsUseCase } from "./application/use-cases/get-organizations.usecase.js";
import { UpdateOrganizationUseCase } from "./application/use-cases/update-organization.usecase.js";
import { DeleteOrganizationUseCase } from "./application/use-cases/delete-organization.usecase.js";

import { OrganizationController } from "./presentation/controllers/organization.controller.js";

export const createOrganizationModule = ({
  companyProfileRepository,
  workspaceSettingsRepository,
  userRepository,
  emailService,
}) => {
  const organizationRepository = new OrganizationRepositoryImpl(AppDataSource);

  const createOrganizationUseCase = new CreateOrganizationUseCase({
    dataSource: AppDataSource,
    organizationRepository,
    companyProfileRepository,
    workspaceSettingsRepository,
    userRepository,
    emailService,
  });

  const getOrganizationsUseCase = new GetOrganizationsUseCase(
    organizationRepository,
  );

  const getOrganizationUseCase = new GetOrganizationUseCase(
    organizationRepository,
  );

  const updateOrganizationUseCase = new UpdateOrganizationUseCase(
    organizationRepository,
  );

  const deleteOrganizationUseCase = new DeleteOrganizationUseCase(
    organizationRepository,
  );

  const organizationController = new OrganizationController({
    createOrganizationUseCase,
    getOrganizationsUseCase,
    getOrganizationUseCase,
    updateOrganizationUseCase,
    deleteOrganizationUseCase,
  });

  return {
    organizationRepository,
    createOrganizationUseCase,
    getOrganizationsUseCase,
    getOrganizationUseCase,
    updateOrganizationUseCase,
    deleteOrganizationUseCase,
    organizationController,
  };
};
