export class OrganizationEntity {
  constructor({
    id,
    name,
    slug,
    ownerId,
    logo = null,
    website = null,
    description = null,
    status = "ACTIVE",
    createdAt,
    updatedAt,
    deletedAt,
  }) {
    this.id = id;
    this.name = name;
    this.slug = slug;
    this.ownerId = ownerId;
    this.logo = logo;
    this.website = website;
    this.description = description;
    this.status = status;

    if (createdAt) this.createdAt = createdAt;
    if (updatedAt) this.updatedAt = updatedAt;
    if (deletedAt) this.deletedAt = deletedAt;
  }
}
