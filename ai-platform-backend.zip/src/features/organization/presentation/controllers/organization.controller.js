export class OrganizationController {
  constructor({
    createOrganizationUseCase,
    getOrganizationsUseCase,
    getOrganizationUseCase,
    updateOrganizationUseCase,
    deleteOrganizationUseCase,
  }) {
    this.createOrganizationUseCase = createOrganizationUseCase;
    this.getOrganizationsUseCase = getOrganizationsUseCase;
    this.getOrganizationUseCase = getOrganizationUseCase;
    this.updateOrganizationUseCase = updateOrganizationUseCase;
    this.deleteOrganizationUseCase = deleteOrganizationUseCase;
  }

  getOrganizations = async (req, res, next) => {
    try {
      const organizations = await this.getOrganizationsUseCase.execute();

      return res.status(200).json({
        success: true,
        data: organizations,
      });
    } catch (error) {
      next(error);
    }
  };

  getOrganizationById = async (req, res, next) => {
    try {
      const organization = await this.getOrganizationUseCase.execute(
        req.params.id,
      );

      return res.status(200).json({
        success: true,
        data: organization,
      });
    } catch (error) {
      next(error);
    }
  };

  createOrganization = async (req, res, next) => {
    try {
      const organization = await this.createOrganizationUseCase.execute({
        name: req.body.name,
        ownerEmail: req.body.ownerEmail,
        logo: req.body.logo,
        website: req.body.website,
        description: req.body.description,
        ownerId: req.user.id,
        createdBy: req.user.id,
      });

      return res.status(201).json({
        success: true,
        message:
          "Organization created successfully. Invitation has been sent to the organization owner.",
        data: organization,
      });
    } catch (error) {
      next(error);
    }
  };

  updateOrganization = async (req, res, next) => {
    try {
      const organization = await this.updateOrganizationUseCase.execute(
        req.params.id,
        req.body,
      );

      return res.status(200).json({
        success: true,
        message: "Organization updated successfully.",
        data: organization,
      });
    } catch (error) {
      next(error);
    }
  };

  deleteOrganization = async (req, res, next) => {
    try {
      const result = await this.deleteOrganizationUseCase.execute(
        req.params.id,
      );

      return res.status(200).json({
        success: true,
        message: result.message,
      });
    } catch (error) {
      next(error);
    }
  };
}
