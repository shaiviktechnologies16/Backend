import { Router } from "express";

import {
  createOrganizationValidator,
  updateOrganizationValidator,
} from "../validators/organization.validator.js";

const createOrganizationRoutes = (organizationController, authMiddleware) => {
  const router = Router();

  router.get("/", authMiddleware, organizationController.getOrganizations);

  router.get(
    "/:id",
    authMiddleware,
    organizationController.getOrganizationById,
  );

  router.post(
    "/",
    authMiddleware,
    createOrganizationValidator,
    organizationController.createOrganization,
  );

  router.patch(
    "/:id",
    authMiddleware,
    updateOrganizationValidator,
    organizationController.updateOrganization,
  );

  router.delete(
    "/:id",
    authMiddleware,
    organizationController.deleteOrganization,
  );

  return router;
};

export default createOrganizationRoutes;
