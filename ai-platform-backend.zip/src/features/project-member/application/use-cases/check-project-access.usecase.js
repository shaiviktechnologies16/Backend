import { AppError } from "../../../../common/errors/AppError.js";

export class CheckProjectAccessUseCase {
  constructor(projectMemberRepository) {
    this.projectMemberRepository = projectMemberRepository;
  }

  async execute({ projectId, userId, allowedRoles = [] }) {
    const member = await this.projectMemberRepository.findByProjectAndUser(
      projectId,
      userId,
    );

    if (!member) {
      throw new AppError(
        "User does not have access to this project.",
        403,
        "PROJECT_ACCESS_DENIED",
      );
    }

    if (member.status === "REMOVED") {
      throw new AppError(
        "Project access has been removed.",
        403,
        "PROJECT_ACCESS_REMOVED",
      );
    }

    if (allowedRoles.length > 0 && !allowedRoles.includes(member.role)) {
      throw new AppError(
        "User does not have permission for this action.",
        403,
        "PROJECT_PERMISSION_FORBIDDEN",
      );
    }

    return member;
  }
}
