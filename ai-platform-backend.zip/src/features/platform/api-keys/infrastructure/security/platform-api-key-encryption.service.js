import crypto from "crypto";

import envConfig from "../../../../../config/env.config.js";

export class PlatformApiKeyEncryptionService {
  constructor() {
    const secret = envConfig.security.apiKeyEncryptionSecret;

    if (!secret) {
      throw new Error("API_KEY_ENCRYPTION_SECRET is not configured.");
    }

    this.key = crypto.createHash("sha256").update(secret).digest();
  }

  encrypt(value) {
    const iv = crypto.randomBytes(16);

    const cipher = crypto.createCipheriv("aes-256-cbc", this.key, iv);

    const encrypted = Buffer.concat([
      cipher.update(value, "utf8"),
      cipher.final(),
    ]);

    return `${iv.toString("hex")}:${encrypted.toString("hex")}`;
  }

  decrypt(value) {
    const [ivHex, encryptedHex] = value.split(":");

    if (!ivHex || !encryptedHex) {
      throw new Error("Invalid encrypted API key.");
    }

    const decipher = crypto.createDecipheriv(
      "aes-256-cbc",
      this.key,
      Buffer.from(ivHex, "hex"),
    );

    const decrypted = Buffer.concat([
      decipher.update(Buffer.from(encryptedHex, "hex")),
      decipher.final(),
    ]);

    return decrypted.toString("utf8");
  }
}
