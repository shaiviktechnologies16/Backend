import { PlatformConfigRepositoryImpl } from "./infrastructure/repositories/platform-config.repository.impl.js";

import { CreatePlatformConfigUseCase } from "./application/use-cases/create-platform-config.usecase.js";
import { GetPlatformConfigUseCase } from "./application/use-cases/get-platform-config.usecase.js";
import { UpdatePlatformConfigUseCase } from "./application/use-cases/update-platform-config.usecase.js";

import { PlatformConfigController } from "./presentation/controllers/platform-config.controller.js";

export function createPlatformConfigModule({ dataSource }) {
  const platformConfigRepository =
    new PlatformConfigRepositoryImpl(dataSource);

  const createPlatformConfigUseCase =
    new CreatePlatformConfigUseCase({
      platformConfigRepository,
    });

  const getPlatformConfigUseCase =
    new GetPlatformConfigUseCase({
      platformConfigRepository,
    });

  const updatePlatformConfigUseCase =
    new UpdatePlatformConfigUseCase({
      platformConfigRepository,
    });

  const platformConfigController =
    new PlatformConfigController(
      createPlatformConfigUseCase,
      getPlatformConfigUseCase,
      updatePlatformConfigUseCase,
    );

  return {
    platformConfigRepository,
    platformConfigController,
    createPlatformConfigUseCase,
    getPlatformConfigUseCase,
    updatePlatformConfigUseCase,
  };
}
