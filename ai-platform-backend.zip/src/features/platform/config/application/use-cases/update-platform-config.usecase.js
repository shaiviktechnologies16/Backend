import { AppError } from "../../../../../common/errors/AppError.js";

export class UpdatePlatformConfigUseCase {
  constructor({ platformConfigRepository, encryptionService }) {
    this.platformConfigRepository = platformConfigRepository;
    this.encryptionService = encryptionService;
  }

  async execute({ configKey, configValue, isSecret, description }) {
    const existing = await this.platformConfigRepository.findByKey(configKey);

    if (!existing) {
      throw new AppError(
        "Platform configuration not found.",
        404,
        "PLATFORM_CONFIG_NOT_FOUND",
      );
    }

    const data = {};

    const finalSecretStatus =
      isSecret !== undefined ? isSecret : existing.isSecret;

    if (configValue !== undefined) {
      data.configValue = finalSecretStatus
        ? this.encryptionService.encrypt(configValue)
        : configValue;
    }

    if (isSecret !== undefined) {
      data.isSecret = isSecret;
    }

    if (description !== undefined) {
      data.description = description;
    }

    return this.platformConfigRepository.update(configKey, data);
  }
}
