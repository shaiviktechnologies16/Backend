export class GetOrganizationModelsUseCase {
  constructor({ organizationModelAccessRepository }) {
    this.organizationModelAccessRepository = organizationModelAccessRepository;
  }

  async execute(organizationId) {
    return this.organizationModelAccessRepository.findByOrganizationId(
      organizationId,
    );
  }
}
