import { AppDataSource } from "../../database/datasource.js";
import { OrganizationRepositoryImpl } from "../organization/infrastructure/repositories/organization.repository.impl.js";
import { OrganizationMemberRepositoryImpl } from "./infrastructure/repositories/organization-member.repository.impl.js";
import { AddMemberUseCase } from "./application/use-cases/add-member.usecase.js";
import { OrganizationMemberController } from "./presentation/controllers/organization-member.controller.js";
import { PostgresUserRepository } from "../auth/repository/postgres/postgres-user.repository.js";
import { GetOrganizationMembersUseCase } from "./application/use-cases/get-organization-members.usecase.js";
import { UpdateMemberRoleUseCase } from "./application/use-cases/update-member-role.usecase.js";
import { RemoveMemberUseCase } from "./application/use-cases/remove-member.usecase.js";

export const createOrganizationMemberModule = () => {
  // Repositories
  const userRepository = new PostgresUserRepository(AppDataSource);
  const organizationRepository = new OrganizationRepositoryImpl(AppDataSource);

  const organizationMemberRepository = new OrganizationMemberRepositoryImpl(
    AppDataSource,
  );

  // Use Cases
  const addMemberUseCase = new AddMemberUseCase(
    organizationRepository,
    organizationMemberRepository,
    userRepository,
  );

  const getOrganizationMembersUseCase = new GetOrganizationMembersUseCase(
    organizationRepository,
    organizationMemberRepository,
  );

  const updateMemberRoleUseCase = new UpdateMemberRoleUseCase(
    organizationRepository,
    organizationMemberRepository,
  );

  const removeMemberUseCase = new RemoveMemberUseCase(
    organizationMemberRepository,
  );

  // Controller
  const organizationMemberController = new OrganizationMemberController(
    addMemberUseCase,
    getOrganizationMembersUseCase,
    updateMemberRoleUseCase,
    removeMemberUseCase,
  );

  return {
    organizationRepository,
    organizationMemberRepository,
    addMemberUseCase,
    getOrganizationMembersUseCase,
    updateMemberRoleUseCase,
    removeMemberUseCase,
    organizationMemberController,
  };
};
