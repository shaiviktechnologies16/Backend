import { Router } from "express";

import { authenticate } from "../../../../common/middleware/auth.middleware.js";

import {
  addMemberValidator,
  updateMemberRoleValidator,
} from "../validators/organization-member.validator.js";

const createOrganizationMemberRoutes = (
  organizationMemberController,
  authMiddleware,
) => {
  const router = Router();

  router.get("/", authMiddleware, organizationMemberController.getMembers);

  router.post(
    "/",
    authMiddleware,
    addMemberValidator,
    organizationMemberController.addMember,
  );

  router.patch(
    "/:userId/role",
    authMiddleware,
    updateMemberRoleValidator,
    organizationMemberController.updateMemberRole,
  );

  router.delete(
    "/:userId",
    authMiddleware,
    organizationMemberController.removeMember,
  );

  return router;
};

export default createOrganizationMemberRoutes;
