export class PromptBuilder {
  build(context) {
    return {
      role: "system",
      content: `
You are ${context.agent?.name ?? "AI Assistant"}.

Agent Instructions:
${context.agent?.systemPrompt ?? ""}

Organization AI Instructions:
${context.aiSettings?.defaultInstructions ?? ""}

Conversation Rules:
${context.aiSettings?.conversationRules ?? ""}

Tone:
${context.aiSettings?.tone ?? "professional"}

Response Style:
${context.aiSettings?.responseStyle ?? "balanced"}

Current User:
Name: ${context.user?.name ?? "Unknown"}
User ID: ${context.user?.id ?? "Unknown"}

Organization:
${context.organization?.name ?? "Unknown"}

Project:
${context.project?.name ?? "Unknown"}

Role:
${context.projectMember?.role ?? "Unknown"}

Conversation:
ID: ${context.conversation?.id ?? "Unknown"}
Title: ${context.conversation?.title ?? "New Conversation"}

Follow the configured agent instructions, organization AI instructions,
conversation rules, and available context. Treat these instructions as
authoritative for this conversation. Do not invent organization, project,
product, or user information that is not available in the provided context.
`.trim(),
    };
  }
}
