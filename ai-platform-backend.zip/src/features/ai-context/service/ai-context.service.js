import { AppError } from "../../../common/errors/AppError.js";
import { AIRequestContext } from "../entity/ai-request-context.js";

export class AIContextService {
  constructor({
    userRepository,
    agentRepository,
    projectRepository,
    projectMemberRepository,
    organizationRepository,
    organizationAISettingsRepository,
    promptBuilder,
    checkProjectAccessUseCase,
  }) {
    this.userRepository = userRepository;
    this.agentRepository = agentRepository;
    this.projectRepository = projectRepository;
    this.projectMemberRepository = projectMemberRepository;
    this.organizationRepository = organizationRepository;
    this.organizationAISettingsRepository = organizationAISettingsRepository;
    this.promptBuilder = promptBuilder;
    this.checkProjectAccessUseCase = checkProjectAccessUseCase;
  }

  async build({ userId, agentId, conversation = null }) {
    const user = await this.userRepository.findById(userId);

    const agent = await this.agentRepository.findById(agentId);

    if (!agent) {
      throw new AppError("Agent not found.", 404, "AGENT_NOT_FOUND");
    }

    let project = null;

    if (agent.projectId) {
      await this.checkProjectAccessUseCase.execute({
        projectId: agent.projectId,
        userId,
      });

      project = await this.projectRepository.findById(agent.projectId);
    }

    let organization = null;
    let projectMember = null;

    if (project?.organizationId) {
      projectMember = await this.projectMemberRepository.findByProjectAndUser(
        agent.projectId,
        userId,
      );

      organization = await this.organizationRepository.findById(
        project.organizationId,
      );
    }

    return new AIRequestContext({
      user,
      organization,
      project,
      agent,
      projectMember,
      conversation,
    });
  }

  buildSystemMessage(context) {
    return this.promptBuilder.build(context);
  }

  async buildPublic({ agentId, conversation = null }) {
    console.log("DEBUG 1: buildPublic START");

    const agent = await this.agentRepository.findById(agentId);

    console.log("DEBUG 2: agent loaded");

    if (!agent) {
      throw new AppError("Agent not found.", 404, "AGENT_NOT_FOUND");
    }

    if (agent.visibility !== "PUBLIC") {
      throw new AppError("Agent is not public.", 403, "AGENT_NOT_PUBLIC");
    }

    let project = null;

    if (agent.projectId) {
      project = await this.projectRepository.findById(agent.projectId);
    }

    console.log("DEBUG 3: project loaded");

    let organization = null;
    let aiSettings = null;

    if (project?.organizationId) {
      organization = await this.organizationRepository.findById(
        project.organizationId,
      );

      console.log("DEBUG 4: organization loaded");

      aiSettings =
        await this.organizationAISettingsRepository.findByOrganizationId(
          project.organizationId,
        );

      console.log("DEBUG 5: AI settings loaded");
    }

    const context = new AIRequestContext({
      user: null,
      organization,
      project,
      agent,
      projectMember: null,
      conversation,
      aiSettings,
    });

    console.log("DEBUG 6: context created");

    return context;
  }
}
