import { Router } from "express";

export default function createProfileRoutes({
  profileController,
  authMiddleware,
}) {
  const router = Router();

  router.get("/", authMiddleware, profileController.getProfile);

  return router;
}
