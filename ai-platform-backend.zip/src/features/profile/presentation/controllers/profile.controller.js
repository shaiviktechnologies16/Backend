export class ProfileController {
  constructor({ getProfileUseCase }) {
    this.getProfileUseCase = getProfileUseCase;
  }

  getProfile = async (req, res, next) => {
    try {
      const profile = await this.getProfileUseCase.execute({
        userId: req.user.id,
        organizationMemberId: null,
      });

      return res.status(200).json({
        success: true,
        data: profile,
      });
    } catch (error) {
      next(error);
    }
  };
}
