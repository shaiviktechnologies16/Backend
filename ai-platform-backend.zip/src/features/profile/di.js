import { GetProfileUseCase } from "./application/use-cases/get-profile.usecase.js";
import { ProfileController } from "./presentation/controllers/profile.controller.js";

export function createProfileModule({
  userRepository,
  organizationRepository,
  organizationMemberRepository,
  projectRepository,
  projectMemberRepository,
  workspaceMemberPermissionRepository,
  rbacRepository,
}) {
  const getProfileUseCase = new GetProfileUseCase({
    userRepository,
    organizationRepository,
    organizationMemberRepository,
    projectRepository,
    projectMemberRepository,
    workspaceMemberPermissionRepository,
    rbacRepository,
  });

  const profileController = new ProfileController({
    getProfileUseCase,
  });

  return {
    profileController,
  };
}
