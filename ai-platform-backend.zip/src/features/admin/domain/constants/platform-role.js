export const PlatformRole = Object.freeze({
  PLATFORM_ADMIN: "PLATFORM_ADMIN",
  PLATFORM_MANAGER: "PLATFORM_MANAGER",
  USER: "USER",
});
