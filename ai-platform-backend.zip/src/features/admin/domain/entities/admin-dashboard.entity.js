export class AdminDashboardEntity {
  constructor({
    users = 0,
    organizations = 0,
    projects = 0,
    agents = 0,
    conversations = 0,
    messages = 0,
    requestsToday = 0,
    tokensToday = 0,
  }) {
    this.users = users;
    this.organizations = organizations;
    this.projects = projects;
    this.agents = agents;
    this.conversations = conversations;
    this.messages = messages;
    this.requestsToday = requestsToday;
    this.tokensToday = tokensToday;
  }
}
