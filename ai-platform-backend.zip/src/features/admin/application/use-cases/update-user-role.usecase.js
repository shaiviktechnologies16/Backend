import { AppError } from "../../../../common/errors/AppError.js";
import { PlatformRole } from "../../domain/constants/platform-role.js";

export class UpdateUserRoleUseCase {
  constructor(adminRepository) {
    this.adminRepository = adminRepository;
  }

  async execute({ userId, platformRole }) {
    const allowedRoles = [
      PlatformRole.USER,
      PlatformRole.PLATFORM_ADMIN,
      PlatformRole.PLATFORM_MANAGER,
    ];

    if (!allowedRoles.includes(platformRole)) {
      throw new AppError("Invalid platform role.", 400, "INVALID_ROLE");
    }

    const user = await this.adminRepository.getUserById(userId);

    if (!user) {
      throw new AppError("User not found.", 404, "USER_NOT_FOUND");
    }

    return this.adminRepository.updatePlatformRole(userId, platformRole);
  }
}
