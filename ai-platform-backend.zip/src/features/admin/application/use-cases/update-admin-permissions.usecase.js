export class UpdateAdminPermissionsUseCase {
  constructor({ userPermissionRepository, permissionRepository }) {
    this.userPermissionRepository = userPermissionRepository;
    this.permissionRepository = permissionRepository;
  }

  async execute({ userId, permissions = [] }) {
    const permissionEntities =
      await this.permissionRepository.findByKeys(permissions);

    const permissionIds = permissionEntities.map((permission) => permission.id);

    // Remove existing permissions
    await this.userPermissionRepository.deleteByUserId(userId);

    // Add new permissions
    if (permissionIds.length) {
      await this.userPermissionRepository.createMany(userId, permissionIds);
    }

    return {
      userId,
      permissions,
    };
  }
}
