import { AppDataSource } from "../../../../database/datasource.js";
import { AdminRepository } from "../../domain/repositories/admin.repository.js";
import { UserOrm } from "../../../../database/entities/user.orm.js";
import { AdminDashboardEntity } from "../../domain/entities/admin-dashboard.entity.js";
import { AdminUserEntity } from "../../domain/entities/admin-user.entity.js";
import { PlatformRole } from "../../domain/constants/platform-role.js";

export class AdminRepositoryImpl extends AdminRepository {
  constructor(dataSource = AppDataSource) {
    super();
    this.dataSource = dataSource;
  }

  async getDashboardStats() {
    const manager = this.dataSource.manager;

    const [users, organizations, projects, agents, conversations, messages] =
      await Promise.all([
        manager.query(`SELECT COUNT(*)::int AS count FROM users`),
        manager.query(`SELECT COUNT(*)::int AS count FROM organizations`),
        manager.query(`SELECT COUNT(*)::int AS count FROM projects`),
        manager.query(`SELECT COUNT(*)::int AS count FROM agents`),
        manager.query(`SELECT COUNT(*)::int AS count FROM conversations`),
        manager.query(`SELECT COUNT(*)::int AS count FROM messages`),
      ]);

    return new AdminDashboardEntity({
      users: users[0].count,
      organizations: organizations[0].count,
      projects: projects[0].count,
      agents: agents[0].count,
      conversations: conversations[0].count,
      messages: messages[0].count,
    });
  }

  async getUsers({
    page = 1,
    limit = 10,
    search = "",
    sortBy = "createdAt",
    sortOrder = "DESC",
    role = null,
    roles = [],
  }) {
    const repository = this.dataSource.getRepository(UserOrm);
    const queryBuilder = repository.createQueryBuilder("user");
    if (roles?.length) {
      queryBuilder.andWhere("user.platformRole IN (:...roles)", { roles });
    } else if (role) {
      queryBuilder.andWhere("user.platformRole = :role", { role });
    }

    if (search?.trim()) {
      queryBuilder.andWhere(
        `(LOWER(user.name) LIKE LOWER(:search)
        OR LOWER(user.email) LIKE LOWER(:search))`,
        {
          search: `%${search.trim()}%`,
        },
      );
    }

    const sortableFields = {
      fullName: "user.name",
      email: "user.email",
      platformRole: "user.platformRole",
      createdAt: "user.createdAt",
      updatedAt: "user.updatedAt",
    };

    queryBuilder.orderBy(
      sortableFields[sortBy] ?? sortableFields.createdAt,
      sortOrder?.toUpperCase() === "ASC" ? "ASC" : "DESC",
    );

    queryBuilder.skip((page - 1) * limit);

    queryBuilder.take(limit);

    const [users, total] = await queryBuilder.getManyAndCount();

    return {
      users: await Promise.all(
        users.map(async (user) => {
          let permissions;

          if (user.platformRole === PlatformRole.PLATFORM_ADMIN) {
            permissions = await this.dataSource.query(`
    SELECT permission_key
    FROM permissions
    ORDER BY permission_key
  `);
          } else {
            permissions = await this.dataSource.query(
              `
    SELECT p.permission_key
    FROM user_permissions up
    JOIN permissions p
    ON p.id = up.permission_id
    WHERE up.user_id = $1
    `,
              [user.id],
            );
          }

          return new AdminUserEntity({
            id: user.id,
            fullName: user.name,
            email: user.email,
            platformRole: user.platformRole,
            isActive: user.isActive,
            permissions: permissions.map((item) => item.permission_key),
            createdAt: user.createdAt,
            updatedAt: user.updatedAt,
          });
        }),
      ),
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getUserById(id) {
    const repository = this.dataSource.getRepository(UserOrm);
    const user = await repository.findOne({
      where: { id },
    });

    if (!user) {
      return null;
    }

    let permissions;

    if (user.platformRole === PlatformRole.PLATFORM_ADMIN) {
      permissions = await this.dataSource.query(`
    SELECT permission_key
    FROM permissions
    ORDER BY permission_key
  `);
    } else {
      permissions = await this.dataSource.query(
        `
    SELECT p.permission_key
    FROM user_permissions up
    JOIN permissions p
    ON p.id = up.permission_id
    WHERE up.user_id = $1
    `,
        [user.id],
      );
    }

    return new AdminUserEntity({
      id: user.id,
      fullName: user.name,
      email: user.email,
      platformRole: user.platformRole,
      permissions: permissions.map((item) => item.permission_key),
      isActive: user.isActive,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    });
  }

  async updatePlatformRole(id, platformRole) {
    const repository = this.dataSource.getRepository(UserOrm);
    await repository.update(id, {
      platformRole,
    });

    return this.getUserById(id);
  }

  async deleteUser(id) {
    const repository = this.dataSource.getRepository(UserOrm);

    await repository.delete(id);
  }

  async countPlatformAdmins() {
    const repository = this.dataSource.getRepository(UserOrm);

    return repository.count({
      where: {
        platformRole: PlatformRole.PLATFORM_ADMIN,
      },
    });
  }

  async updateAdminStatus({ userId, isActive }) {
    const repository = this.dataSource.getRepository(UserOrm);

    const user = await repository.findOne({
      where: { id: userId },
    });

    if (!user) {
      return null;
    }

    user.isActive = isActive;

    await repository.save(user);

    return {
      id: user.id,
      fullName: user.name,
      email: user.email,
      platformRole: user.platformRole,
      isActive: user.isActive,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    };
  }
  async deleteAdmin(userId) {
    const repository = this.dataSource.getRepository(UserOrm);

    await repository.delete(userId);
  }

  async getUserByEmail(email) {
    const repository = this.dataSource.getRepository(UserOrm);
    const user = await repository.findOne({
      where: {
        email,
      },
    });

    return user;
  }

  async createAdmin({
    name,
    email,
    passwordHash,
    platformRole,
    isActive,
    roleId,
  }) {
    const repository = this.dataSource.getRepository(UserOrm);

    const user = repository.create({
      name,
      email,
      passwordHash,
      platformRole,
      isActive,
      role: {
        id: roleId,
      },
    });

    return repository.save(user);
  }
}
