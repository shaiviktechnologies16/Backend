import { AppError } from "../../../../common/errors/AppError.js";
import { generatePublicKey } from "../../../../common/utils/public-key.js";

export class EnablePublicAgentUseCase {
  constructor({ agentRepository }) {
    this.agentRepository = agentRepository;
  }

  async execute(agentId) {
    const agent = await this.agentRepository.findById(agentId);

    if (!agent) {
      throw new AppError("Agent not found.", 404, "AGENT_NOT_FOUND");
    }

    if (agent.visibility === "PUBLIC" && agent.publicKey) {
      return agent;
    }

    agent.enablePublic(generatePublicKey());

    return this.agentRepository.update(agent);
  }
}
