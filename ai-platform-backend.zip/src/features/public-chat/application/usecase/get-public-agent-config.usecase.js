import { AppError } from "../../../../common/errors/AppError.js";

export class GetPublicAgentConfigUseCase {
  constructor({ agentRepository }) {
    this.agentRepository = agentRepository;
  }

  async execute(publicKey) {
    const agent = await this.agentRepository.findByPublicKey(publicKey);

    if (!agent) {
      throw new AppError(
        "Public agent not found.",
        404,
        "PUBLIC_AGENT_NOT_FOUND",
      );
    }

    return {
      id: agent.id,
      name: agent.name,
      description: agent.description,
      widgetConfig: agent.widgetConfig ?? {},
    };
  }
}
