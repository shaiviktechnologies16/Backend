import { createPublicChatController } from "./controller/public-chat.controller.js";
import { GetPublicAgentConfigUseCase } from "./application/usecase/get-public-agent-config.usecase.js";

export const createPublicChatModule = ({ agentRepository }) => {
  const publicAgentConfigUseCase = new GetPublicAgentConfigUseCase({
    agentRepository,
  });

  const publicChatController = createPublicChatController({
    publicAgentConfigUseCase,
  });

  return {
    publicAgentConfigUseCase,
    publicChatController,
  };
};
