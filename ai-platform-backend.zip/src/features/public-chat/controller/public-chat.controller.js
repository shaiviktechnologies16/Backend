import { asyncHandler } from "../../../common/utils/asyncHandler.js";
import { conversationService } from "../../../container/services.js";
import { ValidationError } from "../../../common/errors/ValidationError.js";
import { writeEvent } from "../../../common/utils/sse.js";
import { Logger } from "../../../common/utils/logger.js";

export const createPublicChatController = ({ publicAgentConfigUseCase }) => {
  return {
    publicChat: asyncHandler(async (req, res) => {
      const { message, conversationId } = req.body;

      if (!message || typeof message !== "string") {
        throw new ValidationError("Message is required.");
      }

      const result = await conversationService.sendPublicMessage(
        req.params.publicKey,
        message.trim(),
        req.visitorId ?? null,
        conversationId ?? null,
      );

      res.status(200).json({
        success: true,
        data: result,
      });
    }),

    streamPublicChat: asyncHandler(async (req, res) => {
      const { message, conversationId } = req.body;

      if (!message || typeof message !== "string") {
        throw new ValidationError("Message is required.");
      }

      res.setHeader("Content-Type", "text/event-stream");

      res.setHeader("Cache-Control", "no-cache, no-transform");

      res.setHeader("Connection", "keep-alive");

      res.setHeader("X-Accel-Buffering", "no");

      if (res.flushHeaders) {
        res.flushHeaders();
      }

      try {
        // Force browser to open stream immediately
        res.write(": connected\n\n");

        if (res.flush) {
          res.flush();
        }

        const stream = conversationService.streamPublicMessage(
          req.params.publicKey,
          message.trim(),
          req.visitorId ?? null,
          conversationId ?? null,
        );

        for await (const event of stream) {
          if (event.type === "conversation") {
            writeEvent(res, "conversation", {
              conversationId: event.conversationId,
            });
          }

          if (event.type === "token") {
            writeEvent(res, "token", {
              content: event.content,
            });
          }

          if (event.type === "done") {
            writeEvent(res, "done", {});
          }
        }
      } catch (error) {
        Logger.error("Public streaming failed", error);

        writeEvent(res, "error", {
          message: error.message,
        });
      } finally {
        res.end();
      }
    }),

    getPublicAgentConfig: asyncHandler(async (req, res) => {
      const config = await publicAgentConfigUseCase.execute(
        req.params.publicKey,
      );

      res.status(200).json({
        success: true,
        data: config,
      });
    }),
  };
};
