import "dotenv/config";

import app from "./app.js";
import { appConfig } from "./config/index.js";
import { AppDataSource } from "./database/datasource.js";

const { port, name, version } = appConfig;

async function bootstrap() {
  try {
    await AppDataSource.initialize();

    app.listen(port, () => {
      console.log(`${name} v${version} is running on http://localhost:${port}`);
    });
  } catch (error) {
    console.error("❌ Failed to connect to PostgreSQL");
    console.error(error);
    process.exit(1);
  }
}

bootstrap();
